<?
use Bitrix\Main\{
	Loader,
	HttpApplication,
	Localization\Loc,
	Config\Option as BxOption,
};
use Bitrix\Iblock\{
	IblockTable,
	ElementTable,
	SectionTable
};
use \GreenAtom\ChangeLog\Option as ChangeLogOption;

Loc::loadMessages(__FILE__);

$request = HttpApplication::getInstance()->getContext()->getRequest();

global $APPLICATION;
$module_id = 'greenatom.changelog';
Loader::includeModule($module_id);

// получаем доступные ИБ
$iblocks = [];
$rsIblock = IblockTable::getList([
	'order' => ['NAME' => 'ASC'],
	'select' => [
		'ID',
		'NAME'
	],
	'filter' => [
		'ACTIVE' => 'Y'
	],
]);
while ($iblock = $rsIblock->fetch()) {
	$iblocks[$iblock['ID']] = $iblock['NAME'] . ' [' . $iblock['ID'] . ']';
}

// получаем доступные поля элементов ИБ IBLOCK_ELEMENT_FIELDS
$iblockElementFields = ChangeLogOption::getMapByOrmEntity(new ElementTable());
$iblockElementFieldsDefault = [
	'IBLOCK_SECTION_ID',
	'ACTIVE',
	'ACTIVE_FROM',
	'ACTIVE_TO',
	'SORT',
	'NAME',
	'PREVIEW_PICTURE',
	'PREVIEW_TEXT',
	'PREVIEW_TEXT_TYPE',
	'DETAIL_PICTURE',
	'DETAIL_TEXT',
	'DETAIL_TEXT_TYPE',
	'CODE',
];

// получаем доступные поля разделов ИБ
$iblockSectionFields = ChangeLogOption::getMapByOrmEntity(new SectionTable());
$iblockSectionFieldsDefault = [
	'IBLOCK_SECTION_ID',
	'ACTIVE',
	'SORT',
	'NAME',
	'PICTURE',
	'DESCRIPTION',
	'DESCRIPTION_TYPE',
	'DETAIL_PICTURE',
	'CODE',
];

// получаем доступные поля ИБ, которые логгировать
$aTabs = [
    [
        'DIV' => 'edit',
        'TAB' => Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_SETTINGS'),
        'TITLE' => Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_SETTINGS'),
        'OPTIONS' => [
	        [
		        ChangeLogOption::COUNT_ELEMENT_HISTORY,
		        Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_' . ChangeLogOption::COUNT_ELEMENT_HISTORY),
		        ChangeLogOption::COUNT_ELEMENT_HISTORY_DEFAULT,
		        ['text']
	        ],
            [
                ChangeLogOption::IBLOCK_IDS,
                Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_' . ChangeLogOption::IBLOCK_IDS),
                '',
                ['multiselectbox', $iblocks]
            ],
	        [
		        ChangeLogOption::IBLOCK_ELEMENT_FIELDS,
		        Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_' . ChangeLogOption::IBLOCK_ELEMENT_FIELDS),
		        implode(',', $iblockElementFieldsDefault),
		        ['multiselectbox', $iblockElementFields]
	        ],
	        [
		        ChangeLogOption::IBLOCK_SECTION_FIELDS,
		        Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_' . ChangeLogOption::IBLOCK_SECTION_FIELDS),
		        implode(',', $iblockSectionFieldsDefault),
		        ['multiselectbox', $iblockSectionFields]
	        ],
        ]
    ]
];

if ($request->isPost() && check_bitrix_sessid()) {
    foreach ($aTabs as $aTab) {
        foreach ($aTab['OPTIONS'] as $arOption) {
            if (!is_array($arOption) || $arOption['note']) continue;

            if ($request['apply']) {
                $optionValue = $request->getPost($arOption[0]);
                if ($arOption[0] == 'switch_on') {
                    if (empty($optionValue)) {
                        $optionValue = 'N';
                    }
                }

	            BxOption::set($module_id, $arOption[0], is_array($optionValue) ? implode(',', $optionValue) : $optionValue);

            } elseif ($request['default']) {
	            BxOption::set($module_id, $arOption[0], $arOption[2]);
            }
        }
    }
    LocalRedirect($APPLICATION->GetCurPage() . '?mid=' . $module_id . '&lang=' . LANG);
}

$tabControl = new \CAdminTabControl(
    'tabControl',
    $aTabs
);
$tabControl->Begin();

\Bitrix\Main\UI\Extension::load("ui.alerts");
?>
<?if (strpos($APPLICATION->GetCurPage(),'bitrix/admin')):?>
    <form action="<?=$APPLICATION->GetCurPage()?>?mid=<?=$module_id?>&lang=<?=LANG?>" method="post">
        <?
        foreach ($aTabs as $aTab) {
            if ($aTab['OPTIONS']) {
                $tabControl->BeginNextTab();
                \__AdmSettingsDrawList($module_id, $aTab['OPTIONS']);
            }
        }

        $tabControl->Buttons();
        ?>
        <input type="submit" name="apply" value="<?=Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_APPLY')?>" class="adm-btn-save" />
        <input type="submit" name="default" value="<?=Loc::getMessage('GREENATOM_CHANGELOG_OPTIONS_DEFAULT')?>" />
        <?echo (bitrix_sessid_post());?>
    </form>
<?endif?>

<style>
    #edit_edit_table td > * {
        margin-bottom: 20px;
    }
	#edit_edit_table td select {
        height: 400px;
	}
</style>

<br><br>
<div class="ui-alert ui-alert-icon-warning">
	<span class="ui-alert-message">
		<strong>Внимание!</strong><br><br>
		<strong>Список не отслеживаемых полей элементов и разделов ИБ:</strong><br>
		<ul>
			<li>IBLOCK_ID</li>
			<li>RIGHT_MARGIN</li>
			<li>DEPTH_LEVEL</li>
			<li>SOCNET_GROUP_ID</li>
			<li>CREATED_BY</li>
			<li>MODIFIED_BY</li>
			<li>DATE_CREATE</li>
			<li>TIMESTAMP_X</li>
			<li>SEARCHABLE_CONTENT</li>
			<li>WF_STATUS_ID</li>
			<li>WF_PARENT_ELEMENT_ID</li>
			<li>WF_NEW</li>
			<li>WF_LOCKED_BY</li>
			<li>WF_DATE_LOCK</li>
			<li>WF_COMMENTS</li>
			<li>WF_LOCKED_BY_USER</li>
			<li>IN_SECTIONS</li>
			<li>TMP_ID</li>
			<li>SHOW_COUNTER</li>
			<li>SHOW_COUNTER_START</li>
			<li>WF_PARENT_ELEMENT</li>
		</ul>
		<br><br>

		<strong>Список не отслеживаемых типов UF-свойств:</strong><br>
		<ul>
			<li>resourcebooking - Бронирование ресурсов</li>
			<li>disk_version - Версия файла (Диск)</li>
			<li>video - Видео</li>
			<li>vote - Опрос</li>
			<li>mail_message - Письмо (email)</li>
			<li>url_preview - Содержимое ссылки</li>
			<li>string_formatted - Шаблон</li>
			<li>disk_file - Файл (Диск)</li>
		</ul>
		<br><br>

		<strong>Список не отслеживаемых типов ИБ-свойств:</strong><br>
		<ul>
			<li>S:DiskFile - Файл (Диск)</li>
			<li>E:SKU - Привязка к товарам (SKU)</li>
			<li>S:TopicID - Привязка к теме форума</li>
			<li>S:FileMan - Привязка к файлу (на сервере)</li>
			<li>E:EList - Привязка к элементам в виде списка</li>
			<li>S:video - Видео</li>
		</ul>
	</span>
</div>