<?php
use \Bitrix\Main\Loader;

Loader::includeModule('iblock');
Loader::includeModule('highloadblock');
Loader::includeModule('crm');
Loader::includeModule('currency');