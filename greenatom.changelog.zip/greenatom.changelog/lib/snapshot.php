<?php
namespace GreenAtom\Changelog;

use Bitrix\Main\ORM\Data\Result;
use Bitrix\Main\Type\DateTime;

use GreenAtom\ChangeLog\EntityField\{Field, Userfield, Property, Attribute, EntityFieldInterface};
use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;
use GreenAtom\ChangeLog\Orm\ChangelogTable as ChangelogTable;

class Snapshot
{
	protected $id = 0;
	protected $version = 0;
	protected $dateChange = '';
	protected $modifiedBy = 0;
	protected $fileIds = [];

	/** @var EntityInterface */
	protected EntityInterface $entity;

	/** @var Field[]  */
	protected array $fields = [];

	/** @var Userfield[]  */
	protected array $userfields = [];

	/** @var Property[]  */
	protected array $properties = [];

	/** @var Attribute[]  */
	protected array $attributes = [];

	public function save(): Result
	{
		if ($this->getId() > 0) {
			/*$result = ChangelogTable::update($this->getId(), [
				'VERSION' => $this->getVersion(),
				'MODIFIED_BY' => $this->getModifiedBy(),
				'ENTITY' => $this->getEntity(),
				'SNAPSHOT' => serialize($this),
				'FILE_IDS' => serialize($this->getFileIds()),
			]);*/
		} else {
			$result = ChangelogTable::add([
				'VERSION' => $this->getVersion(),
				'MODIFIED_BY' => $this->getModifiedBy(),
				'DATETIME' => $this->getDateChange(),
				'ENTITY' => $this->getEntity()->getEntity(),
				'SNAPSHOT' => serialize($this),
				'FILE_IDS' => serialize($this->getFileIds()),
			]);
			if ($result->isSuccess()) {
				// дублируем версии файлов
				HelpersFile::checkCreateDoubleForFileIds($this->getFileIds());

				// обновляем объект-shapshot
				$this->id = $result->getId();
				$this->updatePrintable();
				ChangelogTable::update($this->id, ['SNAPSHOT' => serialize($this)]);
			}
		}

		return $result;
	}

	public function delete()
	{
		if ($this->getId() > 0) {
			ChangelogTable::delete($this->getId());

			// удаляем дублирующие версии файлов (если на них больше никто не ссылается)
			HelpersFile::checkDeleteDoubleForFileIds(
				$this->getEntity()->getEntity(),
				$this->getFileIds()
			);
		}
	}

	public function initFilesId()
	{
		$this->fileIds = [];

		foreach ($this->fields as $field) {
			if ($field->isFile()) {
				$this->fileIds = array_merge($this->fileIds, $field->getValues());
			}
		}
		foreach ($this->userfields as $userfield) {
			if ($userfield->isFile()) {
				$this->fileIds = array_merge($this->fileIds, $userfield->getValues());
			}
		}
		foreach ($this->properties as $property) {
			if ($property->isFile()) {
				$this->fileIds = array_merge($this->fileIds, $property->getValues());
			}
		}
	}

	public function isEqual(Snapshot $snapshot): bool
	{
		return ($this->getHash() === $snapshot->getHash());
	}

	protected function getHash(): string
	{
		$hash = '';

		foreach ($this->fields as $field) {
			if ($field->isFile()) {
				$fileIds = $field->getValues();
				foreach ($fileIds as $fileId) {
					$hash .= HelpersFile::getMd5ByFileId($fileId);
				}
			} else {
				$hash .= serialize($field->getValues());
			}
		}
		foreach ($this->userfields as $userfield) {
			if ($userfield->isFile()) {
				$fileIds = $userfield->getValues();
				foreach ($fileIds as $fileId) {
					$hash .= HelpersFile::getMd5ByFileId($fileId);
				}
			} else {
				$hash .= serialize($userfield->getValues());
			}
		}
		foreach ($this->properties as $property) {
			if ($property->isFile()) {
				$fileIds = $property->getValues();
				foreach ($fileIds as $fileId) {
					$hash .= HelpersFile::getMd5ByFileId($fileId);
				}
			} else {
				$hash .= serialize($property->getValues());
			}
		}
		foreach ($this->attributes as $attribute) {
			$hash .= serialize($attribute->getValues());
		}

		return md5($hash);
	}

	public function getEntity(): EntityInterface
	{
		return $this->entity;
	}

	public function setEntity(EntityInterface $entity)
	{
		$this->entity = $entity;
	}

	/**
	 * Добавить поле
	 *
	 * @param Field $field
	 */
	public function addField(Field $field)
	{
		$this->fields[] = $field;
	}

	/**
	 * Добавить UF-поле
	 *
	 * @param Userfield $userfield
	 */
	public function addUserfield(Userfield $userfield)
	{
		$this->userfields[] = $userfield;
	}

	/**
	 * Добавить ИБ-свойство
	 *
	 * @param Property $property
	 */
	public function addProperty(Property $property)
	{
		$this->properties[] = $property;
	}

	/**
	 * Добавить атрибут
	 *
	 * @param Attribute $attribute
	 */
	public function addAttribute(Attribute $attribute)
	{
		$this->attributes[] = $attribute;
	}

	/**
	 * Получить список полей
	 *
	 * @return Field[]
	 */
	public function getFields(): array
	{
		return $this->fields;
	}

	/**
	 * Получить список ИБ-свойств
	 *
	 * @return Property[]
	 */
	public function getProperties(): array
	{
		return $this->properties;
	}

	/**
	 * Получить список UF-полей
	 *
	 * @return Userfield[]
	 */
	public function getUserfields(): array
	{
		return $this->userfields;
	}

	/**
	 * Получить список атрибутов
	 *
	 * @return Attribute[]
	 */
	public function getAttributes(): array
	{
		return $this->attributes;
	}

	/**
	 * Получить список всех полей сущности
	 *
	 * @return EntityFieldInterface[]
	 */
	public function getAllEntityFields(): array
	{
		return array_merge(
			$this->fields,
			$this->properties,
			$this->userfields,
			$this->attributes
		);
	}

	/**
	 * Обновить печатные названия полей и их значения
	 */
	public function updatePrintable()
	{
		foreach ($this->fields as $field) {
			$field->updatePrintable();
		}
		foreach ($this->userfields as $userfield) {
			$userfield->updatePrintable();
		}
		foreach ($this->properties as $property) {
			$property->updatePrintable();
		}
		foreach ($this->attributes as $attribute) {
			$attribute->updatePrintable();
		}
	}

	public function getFieldsForRestore(): array
	{
		$fieldsForRestore = [];

		foreach ($this->fields as $field) {
			if ($field->isMultiple()) {
				$fieldsForRestore[$field->getCode()] = $field->getValuesRestored();
			} else {
				$fieldsForRestore[$field->getCode()] = current($field->getValuesRestored());
			}
		}

		return $fieldsForRestore;
	}

	public function getPropertiesForRestore(): array
	{
		$propertiesForRestore = [];

		foreach ($this->properties as $property) {
			$key = $property->isFile() ? 'FILES' : 'OTHER';
			if ($property->isMultiple()) {
				$valRestored = $property->getValuesRestored();
				if (!empty($valRestored)) {
					$propertiesForRestore[$key][$property->getCode()] = $valRestored;
				} else {
					$propertiesForRestore[$key][$property->getCode()] = false;
				}
			} else {
				$propertiesForRestore[$key][$property->getCode()] = current($property->getValuesRestored());
			}
		}

		return $propertiesForRestore;
	}

	public function getUserfieldsForRestore(): array
	{
		$userfieldsForRestore = [];

		foreach ($this->userfields as $userfield) {
			if ($userfield->isMultiple()) {
				$userfieldsForRestore[$userfield->getCode()] = $userfield->getValuesRestored();
			} else {
				$userfieldsForRestore[$userfield->getCode()] = current($userfield->getValuesRestored());
			}
		}

		return $userfieldsForRestore;
	}

	public function getAttributesForRestore(): array
	{
		$attributesForRestore = [];

		foreach ($this->attributes as $attribute) {
			if ($attribute->isMultiple()) {
				$attributesForRestore[$attribute->getCode()] = $attribute->getValuesRestored();
			} else {
				$attributesForRestore[$attribute->getCode()] = current($attribute->getValuesRestored());
			}
		}

		return $attributesForRestore;
	}

	public function getPictureFields(): array
	{
		return $this->entity->getPictureFields();
	}

	public function getPictureProperties(): array
	{
		$pictureProperties = [];

		foreach ($this->properties as $property) {
			if ($property->isFile()) {
				$pictureProperties[] = $property->getCode();
			}
		}

		return $pictureProperties;
	}

	public function getPictureUserfields(): array
	{
		$pictureUserfields = [];

		foreach ($this->userfields as $userfield) {
			if ($userfield->isFile()) {
				$pictureUserfields[] = $userfield->getCode();
			}
		}

		return $pictureUserfields;
	}

	public function getId(): int
	{
		return (int) $this->id;
	}

	public function getVersion(): int
	{
		return (int) $this->version;
	}

	public function getDateChange(): DateTime
	{
		if ($this->dateChange instanceof DateTime) {
			return $this->dateChange;
		}

		return new DateTime();
	}

	public function getModifiedBy(): int
	{
		return (int) $this->modifiedBy;
	}

	public function getModifiedByPrintable(): string
	{
		return (string) current(HelpersLinked::getUsersPrintableById($this->modifiedBy));
	}

	public function getFileIds(): array
	{
		return (array) $this->fileIds;
	}

	public function setId(int $id)
	{
		$this->id = $id;
	}

	public function setVersion(int $version)
	{
		$this->version = $version;
	}

	public function setDateChange(DateTime $dateChange)
	{
		$this->dateChange = $dateChange;
	}

	public function setModifiedBy(int $modifiedBy)
	{
		$this->modifiedBy = $modifiedBy;
	}

	public function setFileIds(array $fileIds)
	{
		$this->fileIds = $fileIds;
	}

	public static function createFromSerialize(string $data): self
	{
		return unserialize($data);
	}
}