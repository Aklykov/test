<?php

namespace GreenAtom\ChangeLog\Entity;

use Bitrix\Main\{
	Engine\CurrentUser,
	Loader,
	Error,
	Application,
	Localization\Loc,
	ORM\Data\AddResult
};
use Bitrix\Iblock\ElementTable;
use Bitrix\Main\ORM\Data\Result;
use Bitrix\Main\Type\DateTime;

use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\EntityField\{Field, Userfield, Property, Attribute};
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\Changelog\Restore\Analysis;
use GreenAtom\Changelog\Changelog;
use GreenAtom\Changelog\Snapshot;
use GreenAtom\Changelog\Orm\ChangelogTable;
use GreenAtom\ChangeLog\Handlers\Handler;

Loc::loadMessages(__FILE__);

class IblockElement implements EntityInterface
{
	/** @var int ИД элемента инфоблока */
	protected int $elementId;

	/** @var int ИД инфоблока */
	protected int $iblockId;

	public $entity;

	protected static $cache = [
		'propertiesList' => [],
	];

	public function __construct(int $elementId, int $iblockId)
	{
		$this->elementId = (int) $elementId;
		$this->iblockId = (int) $iblockId;

		$this->entity = 'IBLOCK_' . $this->iblockId . '_ELEMENT_' . $this->elementId;
	}

	public function getEntity(): string
	{
		return $this->entity;
	}

	public function getElementId(): int
	{
		return $this->elementId;
	}

	public function getIblockId(): int
	{
		return $this->iblockId;
	}

	public function getName(): string
	{
		return (string) ElementTable::getRow([
			'select' => ['NAME'],
			'filter' => [
				'ID' => $this->elementId,
				'IBLOCK_ID' => $this->iblockId,
			],
			'limit' => 1
		])['NAME'];
	}

	public function getUrlAdminHistory(): string
	{
		return static::URL_ADMIN_HISTORY . '?ENTITY=' . $this->entity;
	}

	public function getSnapshot(): Snapshot
	{
		Loader::includeModule('iblock');
		global $USER_FIELD_MANAGER;

		$snapshot = new Snapshot();
		$snapshot->setEntity($this);
		$snapshot->setModifiedBy(CurrentUser::get()->getId());
		$snapshot->setDateChange(new DateTime());

		// запрашиваем поля
		$iblockElementFields = ChangeLogOption::getIblockElementFields();
		$snapshotFields = \Bitrix\Iblock\ElementTable::getRow([
			'select' => array_merge(['ID'], $iblockElementFields),
			'filter' => [
				'ID' => $this->elementId,
				'IBLOCK_ID' => $this->iblockId,
			],
		]);
		if ($snapshotFields['ID'] > 0) {
			// приводим даты в строковый вид
			foreach ($snapshotFields as $fieldCode => $fieldValue) {
				if ($fieldValue instanceof DateTime) {
					$snapshotFields[$fieldCode] = $fieldValue->format('d.m.Y H:i:s');
				}
			}

			// запрашиваем свойства
			$snapshotProperties = [$snapshotFields['ID'] => $snapshotFields];
			\CIBlockElement::GetPropertyValuesArray(
				$snapshotProperties,
				$this->iblockId,
				['ID' => $this->elementId, 'IBLOCK_ID' => $this->iblockId],
				[]
			);
			$snapshotProperties = current($snapshotProperties);
			// если свойства не нашли - то заглушку их без VALUE берем
			if ($snapshotFields['ID'] == $snapshotProperties['ID']) {
				$snapshotProperties = $this->getPropertiesList();
			}

			$notTrackedTypes = Property::getNotTrackedTypes();
			foreach ($snapshotProperties as $key => $property) {
				$type = Property::getTypeByProperty($property);
				if (in_array($type, $notTrackedTypes)) {
					unset($snapshotProperties[$key]);
				}
			}

			// запрашиваем аттрибуты
			$snapshotAttributes = [];
			if (\Bitrix\Main\Loader::includeModule('greenatom.attributes')) {
				$entityAttr = new \GreenAtom\Attributes\Entity\IblockElement($this->elementId, $this->iblockId);
				$result = $entityAttr->get();
				if ($result->isSuccess()) {
					$snapshotAttributes = $result->getData();
				}
			}

			foreach ($snapshotFields as $fieldCode => $fieldValue) {
				$snapshot->addField(new Field($this, $fieldCode, $fieldValue));
			}
			foreach ($snapshotProperties as $property) {
				$snapshot->addProperty(new Property($this, $property['CODE'], $property));
			}
			foreach ($snapshotAttributes as $attributeTitle => $attributeValue) {
				$snapshot->addAttribute(new Attribute($this, $attributeTitle, $attributeValue));
			}

			$snapshot->initFilesId();
		}

		return $snapshot;
	}

	public function isLogged(): bool
	{
		$iblockIds = ChangeLogOption::getIblockIds();

		return in_array($this->iblockId, $iblockIds);
	}

	public function getPictureFields(): array
	{
		return [
			'PREVIEW_PICTURE',
			'DETAIL_PICTURE',
		];
	}

	public function getLinkedFields(): array
	{
		return [
			'MODIFIED_BY',
			'CREATED_BY',
			'IBLOCK_SECTION_ID',
		];
	}

	public function getFieldCodePrintable($code = ''): string
	{
		$iblockElementFields = ChangeLogOption::getMapByOrmEntity(new ElementTable());

		return $iblockElementFields[$code];
	}

	public function getFieldCodeType($code = ''): string
	{
		$codeType = Field::TYPE_BASE;

		$mapFields = [
			Field::TYPE_DATE => ['TIMESTAMP_X', 'DATE_CREATE', 'WF_DATE_LOCK', 'SHOW_COUNTER_START'],
			Field::TYPE_USER => ['MODIFIED_BY', 'CREATED_BY', 'WF_LOCKED_BY'],
			Field::TYPE_SECTION => ['IBLOCK_SECTION_ID'],
			Field::TYPE_FILE => ['PREVIEW_PICTURE', 'DETAIL_PICTURE'],
			Field::TYPE_CHECKBOX => ['ACTIVE', 'WF_NEW', 'IN_SECTIONS'],
		];
		foreach ($mapFields as $type => $codes) {
			if (in_array($code, $codes)) {
				$codeType = $type;
				break;
			}
		}

		return $codeType;
	}

	public function getPropertiesList()
	{
		if (!empty(static::$cache['propertiesList'])) {
			return static::$cache['propertiesList'];
		} else {
			static::$cache['propertiesList'] = [];
			$rsProperty = \CIBlockProperty::GetList(
				['SORT' => 'ASC', 'ID' => 'ASC'],
				['IBLOCK_ID' => $this->iblockId]
			);
			while ($property = $rsProperty->Fetch()) {
				$property['VALUE'] = [];
				static::$cache['propertiesList'][$property['ID']] = $property;
			}
		}

		return static::$cache['propertiesList'];
	}

	public function restoreSnapshot(Snapshot $snapshot): Result
	{
		Handler::setIgnoreEvent();

		$resultRestore = new Result();

		// -------------------- получаем текущее состояние --------------------
		$changelogTable = new ChangelogTable($this);
		$snapshotCurrent = $changelogTable->getLastVersionSnapshot();
		$snapshotCurrent->updatePrintable();

		// ---------------------------------------- обновляем поля ----------------------------------------
		$fields = $snapshot->getFieldsForRestore();
		$fieldsCurrent = $snapshotCurrent->getFieldsForRestore();

		// убираем поля, которые не менялись
		foreach ($fields as $fieldCode => $fieldValue) {
			if ($fields[$fieldCode] == $fieldsCurrent[$fieldCode]) {
				unset($fields[$fieldCode]);
			}
		}

		// восстановление полей-файлов
		$helpersFile = new HelpersFile($this);
		$pictureFields = $snapshot->getPictureFields();
		foreach ($pictureFields as $pictureField) {
			if (isset($fields[$pictureField])) {
				if ($fields[$pictureField] > 0) {
					$fileId = $fields[$pictureField];
					$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
					if ($helpersFile->isExistByFileId($fileId) === false) {
						$fileData = \CFile::MakeFileArray($doubleFileId);
						$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
						$fileData['MODULE_ID'] = 'iblock';
						$fileData['external_id'] = md5(time());

						$fields[$pictureField] = $fileData;
					}
				} else {
					$fields[$pictureField] = ['del' => 'Y'];
				}
			}
		}

		// update fields
		if (!empty($fields)) {
			$objElement = new \CIBlockElement();
			$fields['IBLOCK_ID'] = $this->getIblockId();
			$isUpdated = $objElement->Update($this->getElementId(), $fields);
			if ($isUpdated === false) {
				$resultRestore->addError(new Error($objElement->LAST_ERROR));
			}
		}

		// ---------------------------------------- обновляем свойства элемента ИБ ----------------------------------------
		$properties = $snapshot->getPropertiesForRestore();
		$propertiesCurrent = $snapshotCurrent->getPropertiesForRestore();

		// удаляем существующие файлы
		$items = [$this->elementId => ['ID' => $this->elementId]];
		\CIBlockElement::GetPropertyValuesArray($items, $this->iblockId, ['ID' => $this->elementId]);
		$clearData = [];
		foreach ($items[$this->elementId] as $propertyData) {
			if ($propertyData['PROPERTY_TYPE'] == Property::TYPE_FILE) {
				if ($propertyData['MULTIPLE'] == 'N') {
					$propertyData['PROPERTY_VALUE_ID'] = [$propertyData['PROPERTY_VALUE_ID']];
				}
				foreach ($propertyData['PROPERTY_VALUE_ID'] as $key => $valueId) {
					$clearData[$propertyData['ID']][$valueId]['VALUE'] = [
						'name' => '',
						'type' => '',
						'tmp_name' => '',
						'error' => 4,
						'size' => 0,
						'del' => 'Y',
					];
				}
			}
		}
		if (!empty($clearData)) {
			\CIBlockElement::SetPropertyValuesEx(
				$this->elementId,
				$this->iblockId,
				$clearData
			);
		}

		// добавляем файлы
		$propertiesFile = [];
		foreach ($properties['FILES'] as $propertyId => $fileIds) {
			if (is_array($fileIds)) {
				foreach ($fileIds as $fileId) {
					$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
					$fileData = \CFile::MakeFileArray($doubleFileId);
					$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
					$fileData['MODULE_ID'] = 'iblock';
					$fileData['external_id'] = md5(time());

					$propertiesFile[$propertyId][] = $fileData;
				}
			} else {
				$fileId = $fileIds;
				$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
				$fileData = \CFile::MakeFileArray($doubleFileId);
				$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
				$fileData['MODULE_ID'] = 'iblock';
				$fileData['external_id'] = md5(time());

				$propertiesFile[$propertyId] = $fileData;
			}
		}

		// восстанавливаем файлы
		if (!empty($propertiesFile)) {
			\CIBlockElement::SetPropertyValuesEx(
				$this->elementId,
				$this->iblockId,
				$propertiesFile
			);
		}

		// восстанавливаем остальные свойства
		\CIBlockElement::SetPropertyValuesEx(
			$this->elementId,
			$this->iblockId,
			$properties['OTHER']
		);

		// ---------------------------------------- обновляем атрибуты ----------------------------------------
		if (\Bitrix\Main\Loader::includeModule('greenatom.attributes')) {
			$attributes = $snapshot->getAttributesForRestore();

			$entityAttr = new \GreenAtom\Attributes\Entity\IblockElement($this->elementId, $this->iblockId);
			$entityAttr->saveAll($attributes);
		}

		Handler::unsetIgnoreEvent();
		// ---------------------------------------- создаем новую запись в истории --------------------
		$changelog = new Changelog($this);
		$result = $changelog->saveSnapshot();
		if ($result->isSuccess() === false) {
			$resultRestore->addErrors($result->getErrors());
		}

		return $resultRestore;
	}
}
