<?php

namespace GreenAtom\ChangeLog\Entity;

use Bitrix\Main\{
	Engine\CurrentUser,
	Loader,
	Error,
	Application,
	Localization\Loc,
	ORM\Data\AddResult
};
use Bitrix\Iblock\SectionTable;
use Bitrix\Main\ORM\Data\Result;
use Bitrix\Main\Type\DateTime;

use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\EntityField\{Field, Userfield, Property, Attribute};
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\Changelog\Restore\Analysis;
use GreenAtom\Changelog\Changelog;
use GreenAtom\Changelog\Snapshot;
use GreenAtom\Changelog\Orm\ChangelogTable;
use GreenAtom\ChangeLog\Handlers\Handler;

Loc::loadMessages(__FILE__);

class IblockSection implements EntityInterface
{
	/** @var int ИД раздела инфоблока */
	protected int $sectionId;

	/** @var int ИД инфоблока */
	protected int $iblockId;

	public $entity;

	protected static $cache = [
		'userfildsList' => [],
	];

	public function __construct(int $sectionId, int $iblockId)
	{
		$this->sectionId = (int) $sectionId;
		$this->iblockId = (int) $iblockId;

		$this->entity = 'IBLOCK_' . $this->iblockId . '_SECTION_' . $this->sectionId;
	}

	public function getEntity(): string
	{
		return $this->entity;
	}

	public function getSectionId(): int
	{
		return $this->sectionId;
	}

	public function getIblockId(): int
	{
		return $this->iblockId;
	}

	public function getName(): string
	{
		return (string) SectionTable::getRow([
			'select' => ['NAME'],
			'filter' => [
				'ID' => $this->sectionId,
				'IBLOCK_ID' => $this->iblockId,
			],
			'limit' => 1
		])['NAME'];
	}

	public function getUrlAdminHistory(): string
	{
		return static::URL_ADMIN_HISTORY . '?ENTITY=' . $this->entity;
	}

	public function getSnapshot(): Snapshot
	{
		Loader::includeModule('iblock');
		global $USER_FIELD_MANAGER;

		$snapshot = new Snapshot();
		$snapshot->setEntity($this);
		$snapshot->setModifiedBy(CurrentUser::get()->getId());
		$snapshot->setDateChange(new DateTime());

		// запрашиваем поля
		$iblockSectionFields = ChangeLogOption::getIblockSectionFields();
		$snapshotFields = \Bitrix\Iblock\SectionTable::getRow([
			'select' => array_merge(['ID'], $iblockSectionFields),
			'filter' => [
				'ID' => $this->sectionId,
				'IBLOCK_ID' => $this->iblockId,
			],
		]);
		if ($snapshotFields['ID'] > 0) {
			// приводим даты в строковый вид
			foreach ($snapshotFields as $fieldCode => $fieldValue) {
				if ($fieldValue instanceof DateTime) {
					$snapshotFields[$fieldCode] = $fieldValue->format('d.m.Y H:i:s');
				}
			}

			// запрашиваем свойства
			$snapshotUserfields = $USER_FIELD_MANAGER->GetUserFields(
				'IBLOCK_'.$this->iblockId.'_SECTION',
				$this->sectionId,
				LANGUAGE_ID
			);
			// исключаем ненужные
			$notTrackedTypes = Userfield::getNotTrackedTypes();
			foreach ($snapshotUserfields as $code => $userfield) {
				if (in_array($userfield['USER_TYPE_ID'], $notTrackedTypes)) {
					unset($snapshotUserfields[$code]);
				}
			}

			// запрашиваем аттрибуты
			$snapshotAttributes = [];
			if (\Bitrix\Main\Loader::includeModule('greenatom.attributes')) {
				$entityAttr = new \GreenAtom\Attributes\Entity\IblockSection($this->sectionId, $this->iblockId);
				$result = $entityAttr->get();
				if ($result->isSuccess()) {
					$snapshotAttributes = $result->getData();
				}
			}

			foreach ($snapshotFields as $fieldCode => $fieldValue) {
				$snapshot->addField(new Field($this, $fieldCode, $fieldValue));
			}
			foreach ($snapshotUserfields as $userfieldCode => $userfieldValue) {
				$snapshot->addUserfield(new Userfield($this, $userfieldCode, $userfieldValue));
			}
			foreach ($snapshotAttributes as $attributeTitle => $attributeValue) {
				$snapshot->addAttribute(new Attribute($this, $attributeTitle, $attributeValue));
			}

			$snapshot->initFilesId();
		}

		return $snapshot;
	}

	public function isLogged(): bool
	{
		$iblockIds = ChangeLogOption::getIblockIds();

		return in_array($this->iblockId, $iblockIds);
	}

	public function getPictureFields(): array
	{
		return [
			'PICTURE',
			'DETAIL_PICTURE',
		];
	}

	public function getLinkedFields(): array
	{
		return [
			'MODIFIED_BY',
			'CREATED_BY',
			'IBLOCK_SECTION_ID',
		];
	}

	public function getFieldCodePrintable($code = ''): string
	{
		$iblockSectionFields = ChangeLogOption::getMapByOrmEntity(new SectionTable());

		return $iblockSectionFields[$code];
	}

	public function getFieldCodeType($code = ''): string
	{
		$codeType = Field::TYPE_BASE;

		$mapFields = [
			Field::TYPE_DATE => ['TIMESTAMP_X', 'DATE_CREATE'],
			Field::TYPE_USER => ['MODIFIED_BY', 'CREATED_BY'],
			Field::TYPE_SECTION => ['IBLOCK_SECTION_ID'],
			Field::TYPE_FILE => ['PICTURE', 'DETAIL_PICTURE'],
			Field::TYPE_CHECKBOX => ['ACTIVE', 'GLOBAL_ACTIVE'],
		];
		foreach ($mapFields as $type => $codes) {
			if (in_array($code, $codes)) {
				$codeType = $type;
				break;
			}
		}

		return $codeType;
	}

	public function getUserfildsList()
	{
		if (!empty(static::$cache['userfildsList'])) {
			return static::$cache['userfildsList'];
		} else {
			global $USER_FIELD_MANAGER;
			static::$cache['userfildsList'] = $USER_FIELD_MANAGER->GetUserFields(
				'IBLOCK_'.$this->getIblockId().'_SECTION',
				0,
				LANGUAGE_ID
			);
		}

		return static::$cache['userfildsList'];
	}

	public function restoreSnapshot(Snapshot $snapshot): Result
	{
		Handler::setIgnoreEvent();

		$resultRestore = new Result();

		// -------------------- получаем текущее состояние --------------------
		$changelogTable = new ChangelogTable($this);
		$snapshotCurrent = $changelogTable->getLastVersionSnapshot();
		$snapshotCurrent->updatePrintable();

		// ---------------------------------------- обновляем поля ----------------------------------------
		$fields = $snapshot->getFieldsForRestore();
		$fieldsCurrent = $snapshotCurrent->getFieldsForRestore();

		// убираем поля, которые не менялись
		foreach ($fields as $fieldCode => $fieldValue) {
			if ($fields[$fieldCode] == $fieldsCurrent[$fieldCode]) {
				unset($fields[$fieldCode]);
			}
		}

		// восстановление полей-файлов
		$helpersFile = new HelpersFile($this);
		$pictureFields = $snapshot->getPictureFields();
		foreach ($pictureFields as $pictureField) {
			if (isset($fields[$pictureField])) {
				$fileId = $fields[$pictureField];
				$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
				if ($helpersFile->isExistByFileId($fileId) === false) {
					$fileData = \CFile::MakeFileArray($doubleFileId);
					$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
					$fileData['MODULE_ID'] = 'iblock';
					$fileData['external_id'] = md5(time());

					$fields[$pictureField] = $fileData;
				}
			}
		}

		// update fields
		if (!empty($fields)) {
			$objSection = new \CIBlockSection();
			$isUpdated = $objSection->Update($this->getSectionId(), $fields);
			if ($isUpdated === false) {
				$resultRestore->addError(new Error($objSection->LAST_ERROR));
			}
		}

		// ---------------------------------------- обновляем свойства ----------------------------------------
		$userfields = $snapshot->getUserfieldsForRestore();
		$userfieldsCurrent = $snapshotCurrent->getUserfieldsForRestore();

		// восстановление свойств-файлов
		$helpersFile = new HelpersFile($this);
		$pictureUserfields = $snapshot->getPictureUserfields();
		foreach ($pictureUserfields as $pictureUserfield) {
			if ($userfields[$pictureUserfield]) {
				$fileIds = $userfields[$pictureUserfield];
				if (is_array($fileIds)) {
					$userfields[$pictureUserfield] = [];
					foreach ($fileIds as $fileId) {
						$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
						$fileData = \CFile::MakeFileArray($doubleFileId);
						$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
						$fileData['MODULE_ID'] = 'iblock';
						$fileData['external_id'] = md5(time());

						$userfields[$pictureUserfield][] = $fileData;
					}
				} else {
					$fileId = $fileIds;
					$doubleFileId = HelpersFile::getDoubleFileIdByFileId($fileId);
					$fileData = \CFile::MakeFileArray($doubleFileId);
					$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);
					$fileData['MODULE_ID'] = 'iblock';
					$fileData['external_id'] = md5(time());

					$userfields[$pictureUserfield] = $fileData;
				}
			}
		}

		global $USER_FIELD_MANAGER;
		$isUpdated = $USER_FIELD_MANAGER->Update(
			'IBLOCK_'.$this->getIblockId().'_SECTION',
			$this->getSectionId(),
			$userfields
		);

		// ---------------------------------------- обновляем атрибуты ----------------------------------------
		if (\Bitrix\Main\Loader::includeModule('greenatom.attributes')) {
			$attributes = $snapshot->getAttributesForRestore();

			$entityAttr = new \GreenAtom\Attributes\Entity\IblockSection($this->sectionId, $this->iblockId);
			$entityAttr->saveAll($attributes);
		}

		Handler::unsetIgnoreEvent();
		// ---------------------------------------- создаем новую запись в истории --------------------
		$changelog = new Changelog($this);
		$result = $changelog->saveSnapshot();
		if ($result->isSuccess() === false) {
			$resultRestore->addErrors($result->getErrors());
		}

		return $resultRestore;
	}
}
