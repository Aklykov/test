<?php

namespace GreenAtom\Changelog\Entity;

use Bitrix\Main\ORM\Data\Result;
use GreenAtom\Changelog\Restore\Analysis;
use GreenAtom\Changelog\Snapshot;

interface EntityInterface
{
	const URL_ADMIN_HISTORY = '/bitrix/admin/greenatom_changelog_history_list.php';

	public function getEntity(): string;
	public function getName(): string;
	public function getUrlAdminHistory(): string;
	public function getSnapshot(): Snapshot;
	public function restoreSnapshot(Snapshot $snapshot): Result;
	public function getPictureFields(): array;
	public function getFieldCodePrintable($code = ''): string;
	public function getFieldCodeType($code = ''): string;
	public function isLogged(): bool;
}