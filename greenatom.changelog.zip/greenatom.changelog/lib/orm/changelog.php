<?php

namespace GreenAtom\ChangeLog\Orm;

use GreenAtom\ChangeLog\{
	Entity\EntityInterface as EntityInterface,
	Helpers\File as HelpersFile,
	Helpers\Linked as HelpersLinked,
	Option as ChangeLogOption,
	Snapshot as Snapshot
};

use Bitrix\Main,
	Bitrix\Main\Localization\Loc,
	Bitrix\Main\Config\Option,
	Bitrix\Main\ORM\Data\DataManager,
	Bitrix\Main\ORM\Fields\Relations\Reference;

use Bitrix\Main\ORM\Fields\{
	IntegerField,
	EnumField,
	DatetimeField,
	ScalarField,
	StringField,
	TextField
};
use Bitrix\Iblock\{
	ElementTable,
	SectionTable
};

Loc::loadMessages(__FILE__);

/**
 * Class ChangelogTable
 *
 * Fields:
 * <ul>
 * <li> ID int mandatory
 * <li> VERSION int mandatory
 * <li> MODIFIED_BY int mandatory
 * <li> DATETIME datetime mandatory
 * <li> ENTITY_TYPE enum ('IBLOCK_ELEMENT', 'IBLOCK_SECTION') mandatory
 * <li> ENTITY_ID int mandatory
 * <li> SNAPSHOT string mandatory
 * <li> MODIFIED_BY_USER reference to {@link \Bitrix\Main\UserTable}
 * </ul>
 *
 * @package \GreenAtom\ChangeLog\Orm
 **/
class ChangelogTable extends Main\Entity\DataManager
{
	protected EntityInterface $changeLogEntity;

	public function __construct(EntityInterface $entity)
	{
		$this->changeLogEntity = $entity;
	}

	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'greenatom_changelog_changelog';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return [
			'ID' => new IntegerField('ID', [
				'primary' => true,
				'autocomplete' => true,
				'title' => 'ID',
			]),
			'VERSION' => new IntegerField('VERSION', [
				'title' => 'Номер версии',
				'required' => true,
			]),
			'MODIFIED_BY' => new IntegerField('MODIFIED_BY', [
				'title' => 'Кто изменил',
				'required' => true,
			]),
			'DATETIME' => new DatetimeField('DATETIME', [
				'title' => 'Дата',
				'required' => true,
				'default_value' => function()
				{
					return new Main\Type\DateTime();
				},
			]),
			'ENTITY' => new StringField('ENTITY', [
				'title' => 'Сущность',
				'required' => true,
			]),
			'SNAPSHOT' => new TextField('SNAPSHOT', [
				'title' => 'Снимок сущности',
				'required' => true,
				'default_value' => '',
			]),
			'FILE_IDS' => new TextField('FILE_IDS', [
				'title' => 'ИД файлов',
				'required' => false,
				'default_value' => '',
			]),
			'MODIFIED_BY_USER' => new Reference(
				'MODIFIED_BY_USER',
				'\Bitrix\Main\User',
				['=this.MODIFIED_BY' => 'ref.ID'],
				['join_type' => 'LEFT']
			),
		];
	}

	public function getFirstVersionSnapshot(): Snapshot
	{
		$snapshot = new Snapshot();

		$item = static::getRow([
			'select' => ['SNAPSHOT'],
			'order' => ['VERSION' => 'ASC'],
			'filter' => ['=ENTITY' => $this->changeLogEntity->entity],
		]);
		if (!empty($item['SNAPSHOT'])) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
		}

		return $snapshot;
	}

	public function getLastVersionSnapshot(): Snapshot
	{
		$snapshot = new Snapshot();

		$item = static::getRow([
			'select' => ['SNAPSHOT'],
			'order' => ['VERSION' => 'DESC'],
			'filter' => ['=ENTITY' => $this->changeLogEntity->entity],
		]);
		if (!empty($item['SNAPSHOT'])) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
		}

		return $snapshot;
	}

	public function getCountRecord(): int
	{
		return (int) static::getCount(['=ENTITY' => $this->changeLogEntity->entity]);
	}

	public function getByVersionSnapshot($version = ''): Snapshot
	{
		$snapshot = new Snapshot();

		$item = static::getRow([
			'select' => ['SNAPSHOT'],
			'order' => ['VERSION' => 'DESC'],
			'filter' => [
				'=VERSION' => $version,
				'=ENTITY' => $this->changeLogEntity->entity,
			],
		]);
		if (!empty($item['SNAPSHOT'])) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
		}

		return $snapshot;
	}

	public function deleteFirstVersion()
	{
		if ($this->getCountRecord() > ChangeLogOption::getCountElementHistory()) {
			$snapshot = $this->getFirstVersionSnapshot();
			$snapshot->delete();
		}
	}

	/**
	 * Получить историю
	 *
	 * @return Snapshot[]
	 */
	public function getHistory(): array
	{
		$items = [];

		$rsItem = static::getList([
			'select' => [
				'SNAPSHOT',
			],
			'order' => ['VERSION' => 'ASC'],
			'filter' => ['ENTITY' => $this->changeLogEntity->entity],
			'limit' => ChangeLogOption::getCountElementHistory(),
		]);
		while ($item = $rsItem->fetch()) {
			$items[] = Snapshot::createFromSerialize($item['SNAPSHOT']);
		}

		return $items;
	}

	public function clearHistory()
	{
		$rsItem = static::getList([
			'select' => ['SNAPSHOT'],
			'filter' => ['=ENTITY' => $this->changeLogEntity->entity],
		]);
		while ($item = $rsItem->fetch()) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
			$snapshot->delete();
		}
	}

	/**
	 * @param string $entity
	 * @return EntityInterface
	 */
	public static function getEntityByEntity($entity = '')
	{
		$item = static::getRow([
			'select' => ['SNAPSHOT'],
			'order' => ['VERSION' => 'DESC'],
			'filter' => [
				'=ENTITY' => $entity,
			],
		]);
		if (!empty($item['SNAPSHOT'])) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
			return $snapshot->getEntity();
		}

		return false;
	}

	public static function clearHistoryAll()
	{
		$rsItem = static::getList([
			'select' => ['SNAPSHOT'],
		]);
		while ($item = $rsItem->fetch()) {
			$snapshot = Snapshot::createFromSerialize($item['SNAPSHOT']);
			$snapshot->delete();
		}
	}
}