<?php

namespace GreenAtom\Changelog\Restore;

use GreenAtom\Changelog\Entity\EntityInterface as EntityInterface;
use GreenAtom\ChangeLog\EntityField\{Field, Userfield, Property, Attribute, EntityFieldInterface};
use GreenAtom\ChangeLog\Orm\ChangelogTable as ChangelogTable;

class Analysis
{
	/**
	 * @var EntityInterface
	 */
	protected EntityInterface $entity;

	/**
	 * @var Alert[]
	 */
	protected array $alerts = [];

	protected int $version;

	public function __construct(EntityInterface $entity, int $version)
	{
		$this->entity = $entity;
		$this->changeLogTable = new ChangelogTable($entity);
		$this->version = $version;

		$this->init();
	}

	protected function init()
	{
		$itemNew = $this->changeLogTable->getByVersionSnapshot($this->version);
		$itemNew->updatePrintable();

		// поля изменения
		$this->initAlert($itemNew->getFields(), Field::getLinkedTypes());

		// свойства ИБ изменения
		$this->initAlert($itemNew->getProperties(), Property::getLinkedTypes());

		// свойства UF изменения
		$this->initAlert($itemNew->getUserfields(), Userfield::getLinkedTypes());

		// атрибуты изменения
		$this->initAlert($itemNew->getAttributes(), Attribute::getLinkedTypes());
	}

	/**
	 * @param EntityFieldInterface[] $news
	 * @param array $linked
	 */
	protected function initAlert(array $news, array $linkedTypes)
	{
		foreach ($news as $new) {
			if (in_array($new->getCodeType(), $linkedTypes)) {
				if ($new->canRestored() === false) {
					$this->alerts[] = new Alert($new);
				}
			}
		}
	}

	/**
	 * @return Alert[]
	 */
	public function getAlerts(): array
	{
		return $this->alerts;
	}

	public function printDebug()
	{
		$htmlTable = '<h3>Список полей которые не будут восстановлены</h3>';
		$htmlTable .= '<ul style="width: 100%;">';
		/** @var Alert $alert */
		foreach ($this->getAlerts() as $alert) {
			$htmlTable .= '<li>' . $alert->getText() . '</li>';
		}
		$htmlTable .= '</ul>';

		echo $htmlTable;
	}
}