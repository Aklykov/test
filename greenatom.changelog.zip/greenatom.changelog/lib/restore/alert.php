<?php

namespace GreenAtom\Changelog\Restore;

use GreenAtom\Changelog\EntityField\EntityFieldInterface;

class Alert
{
	protected EntityFieldInterface $new;

	public function __construct(EntityFieldInterface $new)
	{
		$this->new = $new;
	}

	public function getName()
	{
		return $this->new->getCodePrintable();
	}

	public function getValuesUnRestored()
	{
		return $this->new->getValuesUnRestored();
	}

	public function getText(): string
	{
		$fieldName = $this->getName();
		$values = implode('<br> ', $this->getValuesUnRestored());

		return '<b>'.$fieldName.':</b><br> не будут восстановлены значения: ['.$values.']!';
	}

	public function getEntityField(): EntityFieldInterface
	{
		return $this->new;
	}
}