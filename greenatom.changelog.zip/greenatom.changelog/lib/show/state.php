<?php

namespace GreenAtom\Changelog\Show;

use GreenAtom\Changelog\EntityField\EntityFieldInterface;

class State
{
	protected EntityFieldInterface $new;

	public function __construct(EntityFieldInterface $new)
	{
		$this->new = $new;
	}

	public function getName()
	{
		return $this->new->getCodePrintable();
	}

	public function getValue()
	{
		return $this->new->getValuesPrintable();
	}

	public function getText(): string
	{
		$fieldName = $this->getName();
		$fieldValue = $this->getValue();

		$fieldValue = implode('<br> ', $fieldValue);

		return '<b>'.$fieldName.':</b> <br>'.$fieldValue.'<br><hr>';
	}
}