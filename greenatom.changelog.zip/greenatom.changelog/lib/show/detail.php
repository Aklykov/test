<?php

namespace GreenAtom\Changelog\Show;

use GreenAtom\Changelog\Entity\EntityInterface as EntityInterface;
use GreenAtom\ChangeLog\Orm\ChangelogTable as ChangelogTable;

class Detail
{
	/** @var EntityInterface $entity */
	protected EntityInterface $entity;

	/** @var int $version */
	protected int $version;

	/** @var string $version */
	protected $dateChange;

	/** @var string $version */
	protected $author;

	/** @var State[]  */
	protected array $states;

	public function __construct(EntityInterface $entity, int $version)
	{
		$this->entity = $entity;
		$this->changeLogTable = new ChangelogTable($entity);

		$itemNew = $this->changeLogTable->getByVersionSnapshot($version);
		$itemNew->updatePrintable();

		$this->version = $itemNew->getVersion();
		$this->dateChange = $itemNew->getDateChange();
		$this->author = $itemNew->getModifiedByPrintable();
		$this->states = [];
		foreach ($itemNew->getAllEntityFields() as $EntityField) {
			$this->states[] = new State($EntityField);
		}
	}

	/**
	 * @return State[]
	 */
	public function getStates(): array
	{
		return $this->states;
	}

	public function getVersion()
	{
		return $this->version;
	}

	public function getDateChange()
	{
		return $this->dateChange;
	}

	public function getAuthor()
	{
		return $this->author;
	}

	/**
	 * Получить историю в виде массива
	 *
	 * @return array $items
	 */
	public function getItem(): array
	{
		$item = [
			'version' => $this->getVersion(),
			'dateChange' => $this->getDateChange(),
			'author' => $this->getAuthor(),
			'states' => [],
		];
		foreach ($this->getStates() as $state) {
			$item['states'][] = [
				'name' => $state->getName(),
				'value' => $state->getValue(),
				'text' => $state->getText(),
			];
		}

		return $item;
	}

	/**
	 * Вывод истории в виде HTML (дебаг)
	 */
	public function printDebugDetailTable()
	{
		$htmlTable = '<table style="width: 100%;" cellspacing="2" border="1" cellpadding="5">';

		$htmlTable .= '<tr>';
		$htmlTable .= '<td><b>Версия:</b></td>';
		$htmlTable .= '<td><b>Дата изменения:</b></td>';
		$htmlTable .= '<td><b>Автор:</b></td>';
		$htmlTable .= '<td><b>Поля:</b></td>';
		$htmlTable .= '</tr>';

		$htmlTable .= '<tr>';
		$htmlTable .= '<td style="vertical-align: top;">'.$this->getVersion().'</td>';
		$htmlTable .= '<td style="vertical-align: top;">'.$this->getDateChange().'</td>';
		$htmlTable .= '<td style="vertical-align: top;">'.$this->getAuthor().'</td>';
		$htmlTable .= '<td style="vertical-align: top;">';
		foreach ($this->states as $state) {
			$htmlTable .= $state->getText() . '<br>';
		}

		$htmlTable .= '</table>';

		echo $htmlTable;
	}
}