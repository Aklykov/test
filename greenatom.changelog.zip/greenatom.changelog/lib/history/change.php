<?php

namespace GreenAtom\Changelog\History;

class Change
{
	protected $version;
	protected $dateChange;
	protected $author;

	/**
	 * @var Difference[]
	 */
	protected $differences = [];

	public function __construct($version, $dateChange, $author)
	{
		$this->version = $version;
		$this->dateChange = $dateChange;
		$this->author = $author;
	}

	public function checkDifference(Difference $difference)
	{
		if ($difference->isDifferent()) {
			$this->differences[] = $difference;
		}
	}

	/**
	 * @return Difference[]
	 */
	public function getDifferences(): array
	{
		return $this->differences;
	}

	public function getVersion()
	{
		return $this->version;
	}

	public function getDateChange()
	{
		return $this->dateChange;
	}

	public function getAuthor()
	{
		return $this->author;
	}
}