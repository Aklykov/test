<?php

namespace GreenAtom\Changelog\History;

use GreenAtom\Changelog\EntityField\EntityFieldInterface;
use GreenAtom\Changelog\Helpers\File as HelpersFile;

class Difference
{
	protected EntityFieldInterface $new;
	protected EntityFieldInterface $old;
	protected bool $isDifferent;

	public function __construct(EntityFieldInterface $new, EntityFieldInterface $old)
	{
		$this->new = $new;
		$this->old = $old;
		$this->initDifferent();
	}

	protected function initDifferent()
	{
		$newMd5 = '';
		$oldMd5 = '';

		if ($this->new->isFile()) {
			foreach ($this->new->getValues() as $fileId) {
				$newMd5 .= HelpersFile::getMd5ByFileId($fileId);
			}
			$newMd5 = md5($newMd5);
		} else {
			$newMd5 = md5(serialize($this->new->getValues()));
		}
		if ($this->old->isFile()) {
			foreach ($this->old->getValues() as $fileId) {
				$oldMd5 .= HelpersFile::getMd5ByFileId($fileId);
			}
			$oldMd5 = md5($oldMd5);
		} else {
			$oldMd5 = md5(serialize($this->old->getValues()));
		}

		$this->isDifferent = ($newMd5 !== $oldMd5);
	}

	public function isDifferent()
	{
		return $this->isDifferent;
	}

	public function getName()
	{
		return $this->new->getCodePrintable();
	}

	public function getValueNew()
	{
		return $this->new->getValuesPrintable();
	}

	public function getValueOld()
	{
		return $this->old->getValuesPrintable();
	}

	public function getText(): string
	{
		$fieldName = $this->getName();
		$fieldValueOld = $this->getValueOld();
		$fieldValueNew = $this->getValueNew();

		$fieldValueOld = implode('<br> ', $fieldValueOld);
		$fieldValueNew = implode('<br> ', $fieldValueNew);

		return '<b>'.$fieldName.':</b> <br><b>было</b>:<br>'.$fieldValueOld.' <br><b>стало</b>:<br>'.$fieldValueNew.'<br><hr>';
	}
}
