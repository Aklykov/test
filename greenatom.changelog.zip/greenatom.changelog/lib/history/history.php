<?php

namespace GreenAtom\Changelog\History;

use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\EntityField\{Field, Userfield, Property, Attribute, EntityFieldInterface};
use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\Orm\ChangelogTable;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;
use GreenAtom\Changelog\Restore\Analysis;
use GreenAtom\Changelog\Snapshot;

class History
{
	/**
	 * @var EntityInterface
	 */
	protected EntityInterface $entity;

	/**
	 * @var ChangelogTable
	 */
	protected ChangelogTable $changeLogTable;

	/**
	 * @var Change[]
	 */
	protected array $changes = [];
	protected Change $changeCurrent;

	public function __construct(EntityInterface $entity)
	{
		$this->entity = $entity;
		$this->changeLogTable = new ChangelogTable($entity);

		$this->init();
	}

	/**
	 * @return Change[]
	 */
	public function getChanges(): array
	{
		$this->changes;
	}

	/**
	 * Получить историю в виде массива
	 *
	 * @return array $items
	 */
	public function getItems(): array
	{
		$items = [];

		foreach ($this->changes as $change) {
			$item = [
				'version' => $change->getVersion(),
				'dateChange' => $change->getDateChange(),
				'author' => $change->getAuthor(),
				'differences' => [],
				'alerts' => [],
			];
			foreach ($change->getDifferences() as $difference) {
				$item['differences'][] = [
					'name' => $difference->getName(),
					'valueNew' => $difference->getValueNew(),
					'valueOld' => $difference->getValueOld(),
					'text' => $difference->getText(),
				];
			}
			$analize = new Analysis($this->entity, $change->getVersion());
			foreach ($analize->getAlerts() as $alert) {
				$item['alerts'][] = [
					'name' => $alert->getName(),
					'valuesUnRestored' => $alert->getValuesUnRestored(),
					'text' => $alert->getText(),
				];
			}

			$items[] = $item;
		}

		return $items;
	}

	protected function init()
	{
		$items = $this->changeLogTable->getHistory();

		$itemOld = new Snapshot();
		foreach ($items as $itemNew) {
			$itemNew->updatePrintable();
			$this->initChanges($itemNew, $itemOld);
			$itemOld = $itemNew;
		}

		$this->changes = array_reverse($this->changes);
	}

	protected function initChanges(Snapshot $itemNew, Snapshot $itemOld): Change
	{
		// создаем изменение
		$this->changeCurrent = new Change(
			$itemNew->getVersion(),
			$itemNew->getDateChange()->format('d.m.Y H:i:s'),
			$itemNew->getModifiedByPrintable(),
		);

		// поля изменения
		$this->initChange($itemNew->getFields(), $itemOld->getFields(), Field::class);

		// свойства ИБ изменения
		$this->initChange($itemNew->getProperties(), $itemOld->getProperties(), Property::class);

		// свойства UF изменения
		$this->initChange($itemNew->getUserfields(), $itemOld->getUserfields(), Userfield::class);

		// атрибуты изменения
		$this->initChange($itemNew->getAttributes(), $itemOld->getAttributes(), Attribute::class);

		// добавляем изменение
		$this->changes[] = $this->changeCurrent;

		return $this->changeCurrent;
	}

	/**
	 * @param EntityFieldInterface[] $news
	 * @param EntityFieldInterface[] $olds
	 * @param string $entityfield
	 */
	protected function initChange(array $news, array $olds, $entityfield)
	{
		$differences = [];

		foreach ($news as $new) {
			$fieldCode = $new->getCode();
			foreach ($olds as $old) {
				if ($fieldCode == $old->getCode() && !isset($differences[$fieldCode])) {
					$differences[$fieldCode] = new Difference($new, $old);
				}
			}
			if (!isset($differences[$fieldCode])) {
				$old = new $entityfield($this->entity, $fieldCode, '');
				$differences[$fieldCode] = new Difference($new, $old);
			}
		}
		foreach ($olds as $old) {
			$fieldCode = $old->getCode();
			foreach ($news as $new) {
				if ($fieldCode == $new->getCode() && !isset($differences[$fieldCode])) {
					$differences[$fieldCode] = new Difference($new, $old);
				}
			}
			if (!isset($differences[$fieldCode])) {
				$new = new $entityfield($this->entity, $fieldCode, '');
				$differences[$fieldCode] = new Difference($new, $old);
			}
		}

		foreach ($differences as $difference) {
			$this->changeCurrent->checkDifference($difference);
		}
	}

	/**
	 * Вывод истории в виде HTML (дебаг)
	 */
	public function printDebugHistoryTable()
	{
		$htmlTable = '<table style="width: 100%;" cellspacing="2" border="1" cellpadding="5">';

		$htmlTable .= '<tr>';
		$htmlTable .= '<td><b>Версия:</b></td>';
		$htmlTable .= '<td><b>Дата изменения:</b></td>';
		$htmlTable .= '<td><b>Автор:</b></td>';
		$htmlTable .= '<td><b>Изменения:</b></td>';
		$htmlTable .= '</tr>';

		/** @var Change $change */
		foreach ($this->changes as $change) {
			$htmlTable .= '<tr>';
			$htmlTable .= '<td style="vertical-align: top;">'.$change->getVersion().'</td>';
			$htmlTable .= '<td style="vertical-align: top;">'.$change->getDateChange().'</td>';
			$htmlTable .= '<td style="vertical-align: top;">'.$change->getAuthor().'</td>';
			$htmlTable .= '<td style="vertical-align: top;">';
			foreach ($change->getDifferences() as $difference) {
				$htmlTable .= $difference->getText() . '<br>';
			}
		}

		$htmlTable .= '</table>';

		echo $htmlTable;
	}
}