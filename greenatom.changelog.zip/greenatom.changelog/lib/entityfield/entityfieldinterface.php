<?php
namespace GreenAtom\Changelog\EntityField;

use GreenAtom\Changelog\Entity\EntityInterface;

interface EntityFieldInterface
{
	public function __construct(EntityInterface $entity, $code, $source);
	public function isMultiple(): bool;
	public function isFile(): bool;
	public function getCode(): string;
	public function getCodePrintable(): string;
	public function getValues(): array;
	public function getValuesPrintable(): array;
	public function canRestored(): bool;
	public function getValuesUnRestored(): array;
	public function updatePrintable();
	public static function getNotTrackedTypes(): array;
	public static function getLinkedTypes(): array;
}