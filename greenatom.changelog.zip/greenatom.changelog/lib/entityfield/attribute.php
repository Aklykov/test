<?php

namespace GreenAtom\ChangeLog\EntityField;

use Bitrix\Iblock\{ElementTable, SectionTable};
use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;
use Bitrix\Highloadblock\HighloadBlockTable;

class Attribute implements EntityFieldInterface
{
	protected EntityInterface $entity;

	protected $code;
	protected $source;
	protected $values;
	protected $valuesRestored;
	protected $valuesUnRestored;
	protected $codePrintable;
	protected $valuesPrintable;
	protected $isFile;
	protected $isMultiple;
	protected $codeType;

	public function __construct(EntityInterface $entity, $code, $source)
	{
		$this->entity = $entity;
		$this->code = $code;
		$this->source = $source;

		$this->values = [];
		if (is_array($source)) {
			$this->values = $source;
		} else if (!empty($source)) {
			$this->values = [$source];
		}

		$this->valuesRestored = [];
		$this->valuesUnRestored = [];

		$this->updatePrintable();
	}

	public function getCode(): string
	{
		return (string) $this->code;
	}

	public function getValues(): array
	{
		return $this->values;
	}

	public function getCodePrintable(): string
	{
		return (string) $this->codePrintable;
	}

	public function getValuesPrintable(): array
	{
		return $this->valuesPrintable;
	}

	public function getCodeType()
	{
		return $this->codeType;
	}

	public function canRestored(): bool
	{
		return count($this->valuesUnRestored) === 0;
	}

	public function getValuesRestored(): array
	{
		return (array) $this->valuesRestored;
	}

	public function getValuesUnRestored(): array
	{
		return (array) $this->valuesUnRestored;
	}

	public function isFile(): bool
	{
		return (bool) $this->isFile;
	}

	public function isMultiple(): bool
	{
		return (bool) $this->isMultiple;
	}

	public function updatePrintable()
	{
		$codePrintable = $this->code . ' [атрибут]';
		$this->code = $this->code;
		$this->codeType = 'string';
		$this->isMultiple = false;
		$this->isFile = false;

		$values = $this->values;
		$valuesPrintable = [];

		$valuesRestored = $values;
		$valuesUnRestored = [];

		foreach ($values as $value) {
			$valuesPrintable[] = $value;
		}

		if (!empty($this->valuesPrintable)) {
			foreach ($this->valuesPrintable as $key => $valuePrintable) {
				if (empty($valuesPrintable[$key])) {
					$valuesPrintable[$key] = $this->valuesPrintable[$key];
				}
			}
		} else if (empty($valuesPrintable)) {
			$valuesPrintable = $values;
		}

		$this->valuesRestored = (array) $valuesRestored;
		$this->valuesUnRestored = (array) $valuesUnRestored;

		$this->codePrintable = $codePrintable;
		$this->valuesPrintable = (array) $valuesPrintable;
	}

	public static function getNotTrackedTypes(): array
	{
		return [];
	}

	public static function getLinkedTypes(): array
	{
		return [];
	}
}