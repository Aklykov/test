<?php

namespace GreenAtom\ChangeLog\EntityField;

use Bitrix\Iblock\{ElementTable, SectionTable};
use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;

class Userfield implements EntityFieldInterface
{
	const TYPE_ADDRESS = 'address'; // Адрес
	const TYPE_BOOLEAN = 'boolean'; // Да/Нет
	const TYPE_DATE = 'date'; // Дата
	const TYPE_DATETIME = 'datetime'; // Дата со временем
	const TYPE_MONEY = 'money'; // Деньги
	const TYPE_IBLOCK_SECTION = 'iblock_section'; // Привязка к разделам инф. блоков
	const TYPE_EMPLOYEE = 'employee'; // Привязка к сотруднику
	const TYPE_CRM_STATUS = 'crm_status'; // Привязка к справочникам CRM
	const TYPE_CRM = 'crm'; // Привязка к элементам CRM
	const TYPE_HLBLOCK = 'hlblock'; // Привязка к элементам highload-блоков
	const TYPE_IBLOCK_ELEMENT = 'iblock_element'; // Привязка к элементам инф. блоков
	const TYPE_ENUMERATION = 'enumeration'; // Список
	const TYPE_URL = 'url'; // Ссылка
	const TYPE_STRING = 'string'; // Строка
	const TYPE_FILE = 'file'; // Файл
	const TYPE_INTEGER = 'integer'; // Целое число
	const TYPE_DOUBLE = 'double'; // Число

	// untracked
	const TYPE_RESOURCEBOOKING = 'resourcebooking'; // Бронирование ресурсов
	const TYPE_DISK_VERSION = 'disk_version'; // Версия файла (Диск)
	const TYPE_VIDEO = 'video'; // Видео
	const TYPE_VOTE = 'vote'; // Опрос
	const TYPE_MAIL_MESSAGE = 'mail_message'; // Письмо (email)
	const TYPE_URL_PREVIEW = 'url_preview'; // Содержимое ссылки
	const TYPE_STRING_FORMATTED = 'string_formatted'; // Шаблон
	const TYPE_DISK_FILE = 'disk_file'; // Файл (Диск)

	protected EntityInterface $entity;

	protected $code;
	protected $source;
	protected $values;
	protected $valuesRestored;
	protected $valuesUnRestored;
	protected $codePrintable;
	protected $valuesPrintable;
	protected $isFile;
	protected $isMultiple;
	protected $codeType;

	public function __construct(EntityInterface $entity, $code, $source)
	{
		$this->entity = $entity;
		$this->code = $code;
		$this->source = $source;

		$this->values = [];
		if (is_array($source['VALUE'])) {
			$this->values = $source['VALUE'];
		} else if (!empty($source['VALUE'])) {
			$this->values = [$source['VALUE']];
		}

		$this->valuesRestored = [];
		$this->valuesUnRestored = [];

		$this->updatePrintable();
	}

	public function getCode(): string
	{
		return (string) $this->code;
	}

	public function getValues(): array
	{
		return $this->values;
	}

	public function getCodePrintable(): string
	{
		return (string) $this->codePrintable;
	}

	public function getValuesPrintable(): array
	{
		return $this->valuesPrintable;
	}

	public function getCodeType()
	{
		return $this->codeType;
	}

	public function canRestored(): bool
	{
		return count($this->valuesUnRestored) === 0;
	}

	public function getValuesRestored(): array
	{
		return (array) $this->valuesRestored;
	}

	public function getValuesUnRestored(): array
	{
		return (array) $this->valuesUnRestored;
	}

	public function isFile(): bool
	{
		return (bool) $this->isFile;
	}

	public function isMultiple(): bool
	{
		return (bool) $this->isMultiple;
	}

	public function updatePrintable()
	{
		$userfieldsList = $this->entity->getUserfildsList();

		$codePrintable = $userfieldsList[$this->code]['EDIT_FORM_LABEL'] . ' [' . $this->code . ']';
		$this->codeType = $userfieldsList[$this->code]['USER_TYPE_ID'];
		$this->isMultiple = ($userfieldsList[$this->code]['MULTIPLE'] == 'Y');

		$values = $this->values;
		$valuesPrintable = [];

		$valuesRestored = $values;
		$valuesUnRestored = [];
		switch ($this->codeType) {
			case static::TYPE_ADDRESS:
				foreach ($values as $value) {
					$valuesPrintable[] = current(explode('|', $value));
				}
				break;
			case static::TYPE_STRING:
			case static::TYPE_INTEGER:
			case static::TYPE_DOUBLE:
			case static::TYPE_URL:
			case static::TYPE_DATE:
			case static::TYPE_DATETIME:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
				break;
			case static::TYPE_BOOLEAN:
				foreach ($values as $value) {
					if ($value !== NULL) {
						$valuesPrintable[] = ($value > 0) ? 'Да' : 'Нет';
					} else {
						$valuesPrintable[] = '';
					}
				}
				break;
			case static::TYPE_MONEY:
				$valuesPrintable = HelpersLinked::getMoneyPrintable($values);
				break;
			case static::TYPE_IBLOCK_SECTION:
				$valuesPrintable = HelpersLinked::getSectionsPrintableById($values, $this->source['SETTINGS']['IBLOCK_ID']);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_EMPLOYEE:
				$valuesPrintable = HelpersLinked::getUsersPrintableById($values);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_CRM_STATUS:
				$valuesPrintable = HelpersLinked::getCrmStatusesPrintable($values, (array) $this->source);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_CRM:
				$valuesPrintable = HelpersLinked::getCrmElementsPrintable($values, (array) $this->source);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_HLBLOCK:
				$valuesPrintable = HelpersLinked::getElementsHLPrintableById($values, $this->source['SETTINGS']['HLBLOCK_ID']);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_IBLOCK_ELEMENT:
				$valuesPrintable = HelpersLinked::getElementsPrintableById($values, $this->source['SETTINGS']['IBLOCK_ID']);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_ENUMERATION:
				$valuesPrintable = HelpersLinked::getUserfieldEnumValues($values);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_FILE:
				$fileIds = [];
				foreach ($values as $value) {
					if ($value > 0) {
						$fileIds[] = HelpersFile::getDoubleFileIdByFileId($value);
					}
				}
				$this->isFile = !empty($fileIds);
				$valuesPrintable = HelpersLinked::getFilesPrintableById($fileIds);
				break;
			default:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
		}

		if (!empty($this->valuesPrintable)) {
			foreach ($this->valuesPrintable as $key => $valuePrintable) {
				if (empty($valuesPrintable[$key])) {
					$valuesPrintable[$key] = $this->valuesPrintable[$key];
				}
			}
		} else if (empty($valuesPrintable)) {
			$valuesPrintable = $values;
		}

		$this->valuesRestored = (array) $valuesRestored;
		$this->valuesUnRestored = (array) $valuesUnRestored;

		$this->codePrintable = $codePrintable;
		$this->valuesPrintable = (array) $valuesPrintable;
	}

	public static function getNotTrackedTypes(): array
	{
		return [
			static::TYPE_RESOURCEBOOKING,
			static::TYPE_DISK_VERSION,
			static::TYPE_VIDEO,
			static::TYPE_VOTE,
			static::TYPE_MAIL_MESSAGE,
			static::TYPE_URL_PREVIEW,
			static::TYPE_STRING_FORMATTED,
			static::TYPE_DISK_FILE,
		];
	}

	public static function getLinkedTypes(): array
	{
		return [
			static::TYPE_IBLOCK_SECTION,
			static::TYPE_EMPLOYEE,
			static::TYPE_CRM_STATUS,
			static::TYPE_CRM,
			static::TYPE_HLBLOCK,
			static::TYPE_IBLOCK_ELEMENT,
			static::TYPE_ENUMERATION,
		];
	}
}