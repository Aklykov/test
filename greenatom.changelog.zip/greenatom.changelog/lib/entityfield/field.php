<?php

namespace GreenAtom\ChangeLog\EntityField;

use Bitrix\Iblock\{ElementTable, SectionTable};
use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;

class Field implements EntityFieldInterface
{
	const TYPE_BASE = 'base';
	const TYPE_DATE = 'date';
	const TYPE_USER = 'user';
	const TYPE_ELEMENT = 'element';
	const TYPE_SECTION = 'section';
	const TYPE_FILE = 'file';
	const TYPE_CHECKBOX = 'checkbox';

	protected EntityInterface $entity;

	protected $code;
	protected $source;
	protected $values;
	protected $valuesRestored;
	protected $valuesUnRestored;
	protected $codePrintable;
	protected $valuesPrintable;
	protected $isFile;
	protected $isMultiple;
	protected $codeType;

	public function __construct(EntityInterface $entity, $code, $source)
	{
		$this->entity = $entity;
		$this->code = $code;
		$this->source = $source;

		$this->values = [];
		if (is_array($source)) {
			$this->values = $source;
		} else if (!empty($source)) {
			$this->values = [$source];
		}

		$this->valuesRestored = [];
		$this->valuesUnRestored = [];

		$this->updatePrintable();
	}

	public function getCode(): string
	{
		return (string) $this->code;
	}

	public function getCodePrintable(): string
	{
		return (string) $this->codePrintable;
	}

	public function getValues(): array
	{
		return $this->values;
	}

	public function getValuesPrintable(): array
	{
		return $this->valuesPrintable;
	}

	public function getCodeType()
	{
		return $this->codeType;
	}

	public function canRestored(): bool
	{
		return count($this->valuesUnRestored) === 0;
	}

	public function getValuesRestored(): array
	{
		return (array) $this->valuesRestored;
	}

	public function getValuesUnRestored(): array
	{
		return (array) $this->valuesUnRestored;
	}

	public function isFile(): bool
	{
		return (bool) $this->isFile;
	}

	public function isMultiple(): bool
	{
		return (bool) $this->isMultiple;
	}

	public function updatePrintable()
	{
		$codePrintable = $this->entity->getFieldCodePrintable($this->code);
		$this->codeType = $this->entity->getFieldCodeType($this->code);
		$this->isMultiple = false;

		$values = $this->values;
		$valuesPrintable = [];

		$valuesRestored = $values;
		$valuesUnRestored = [];
		switch ($this->codeType) {
			case static::TYPE_DATE:
				foreach ($values as $value) {
					if ($value instanceof \Bitrix\Main\Type\Date) {
						$valuesPrintable[] = $value->format('d.m.Y H:i:s');
					}
				}
				break;
			case static::TYPE_USER:
				$valuesPrintable = HelpersLinked::getUsersPrintableById($values);
				break;
			case static::TYPE_SECTION:
				$valuesPrintable = HelpersLinked::getSectionsPrintableById($values, $this->entity->getIblockId());

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_FILE:
				$fileIds = [];
				foreach ($values as $value) {
					if ($value > 0) {
						$fileIds[] = HelpersFile::getDoubleFileIdByFileId($value);
					}
				}
				$this->isFile = !empty($fileIds);
				$valuesPrintable = HelpersLinked::getFilesPrintableById($fileIds);
				break;
			case static::TYPE_CHECKBOX:
				foreach ($values as $value) {
					$valuesPrintable[] = ($value == 'Y') ? 'Да' : 'Нет';
				}
				break;
			case static::TYPE_BASE:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
				break;
			default:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
				break;
		}

		if (!empty($this->valuesPrintable)) {
			foreach ($this->valuesPrintable as $key => $valuePrintable) {
				if (empty($valuesPrintable[$key])) {
					$valuesPrintable[$key] = $this->valuesPrintable[$key];
				}
			}
		} else if (empty($valuesPrintable)) {
			$valuesPrintable = $values;
		}

		$this->valuesRestored = (array) $valuesRestored;
		$this->valuesUnRestored = (array) $valuesUnRestored;

		$this->codePrintable = $codePrintable;
		$this->valuesPrintable = (array) $valuesPrintable;
	}

	public static function getNotTrackedTypes(): array
	{
		return [];
	}

	public static function getLinkedTypes(): array
	{
		return [
			static::TYPE_ELEMENT,
			static::TYPE_SECTION,
		];
	}
}