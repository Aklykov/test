<?php

namespace GreenAtom\ChangeLog\EntityField;

use Bitrix\Iblock\{ElementTable, SectionTable};
use GreenAtom\Changelog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Option as ChangeLogOption;
use GreenAtom\ChangeLog\Helpers\File as HelpersFile;
use GreenAtom\ChangeLog\Helpers\Linked as HelpersLinked;
use Bitrix\Highloadblock\HighloadBlockTable;

class Property implements EntityFieldInterface
{
	const TYPE_STRING = 'S'; // Строка
	const TYPE_NUMBER = 'N'; // Число
	const TYPE_LIST = 'L'; // Список
	const TYPE_FILE = 'F'; // Файл
	const TYPE_ELEMENT = 'E'; // Привязка к элементам
	const TYPE_SECTION = 'G'; // Привязка к разделам

	const TYPE_HTML = 'S:HTML'; // HTML/текст
	const TYPE_DATE = 'S:Date'; // Дата
	const TYPE_DATETIME = 'S:DateTime'; // Дата/Время
	const TYPE_MONEY = 'S:Money'; // Деньги
	const TYPE_MAP_YANDEX = 'S:map_yandex'; // Привязка к Яндекс.Карте
	const TYPE_MAP_GOOGLE = 'S:map_google'; // Привязка к карте Google Maps
	const TYPE_USER_ID = 'S:UserID'; // Привязка к пользователю
	const TYPE_SECTION_AUTO = 'G:SectionAuto'; // Привязка к разделам с автозаполнением
	const TYPE_EMPLOYEE = 'S:employee'; // Привязка к сотруднику
	const TYPE_ELEMENT_CRM = 'S:ECrm'; // Привязка к элементам CRM
	const TYPE_ELEMENT_XML_ID = 'S:ElementXmlID'; // Привязка к элементам по XML_ID
	const TYPE_ELEMENT_AUTO = 'E:EAutocomplete'; // Привязка к элементам с автозаполнением
	const TYPE_DIRECTORY = 'S:directory'; // Справочник
	const TYPE_SEQUENCE = 'N:Sequence'; // Счетчик

	// untracked
	const TYPE_DISK_FILE = 'S:DiskFile'; // Файл (Диск)
	const TYPE_SKU = 'E:SKU'; // Привязка к товарам (SKU)
	const TYPE_TOPIC_ID = 'S:TopicID'; // Привязка к теме форума
	const TYPE_FILEMAN = 'S:FileMan'; // Привязка к файлу (на сервере)
	const TYPE_ELEMENT_LIST = 'E:EList'; // Привязка к элементам в виде списка
	const TYPE_VIDEO = 'S:video'; // Видео

	protected EntityInterface $entity;

	protected $code;
	protected $source;
	protected $values;
	protected $valuesRestored;
	protected $valuesUnRestored;
	protected $codePrintable;
	protected $valuesPrintable;
	protected $isFile;
	protected $isMultiple;
	protected $codeType;

	public function __construct(EntityInterface $entity, $code, $source)
	{
		$this->entity = $entity;
		$this->code = $this->source['ID'];
		$this->source = $source;

		$this->values = [];
		if (is_array($source['VALUE'])) {
			$this->values = $source['VALUE'];
		} else if (!empty($source['VALUE'])) {
			$this->values = [$source['VALUE']];
		}

		$this->valuesRestored = [];
		$this->valuesUnRestored = [];

		$this->updatePrintable();
	}

	public function getCode(): string
	{
		return (string) $this->code;
	}

	public function getValues(): array
	{
		return $this->values;
	}

	public function getCodePrintable(): string
	{
		return (string) $this->codePrintable;
	}

	public function getValuesPrintable(): array
	{
		return $this->valuesPrintable;
	}

	public function getCodeType()
	{
		return $this->codeType;
	}

	public function canRestored(): bool
	{
		return count($this->valuesUnRestored) === 0;
	}

	public function getValuesRestored(): array
	{
		if ($this->codeType == static::TYPE_HTML) {
			return array_map(function($item){
				return ['VALUE' => $item];
			}, $this->valuesRestored);
		}

		return (array) $this->valuesRestored;
	}

	public function getValuesUnRestored(): array
	{
		return (array) $this->valuesUnRestored;
	}

	public function isFile(): bool
	{
		return (bool) $this->isFile;
	}

	public function isMultiple(): bool
	{
		return (bool) $this->isMultiple;
	}

	public function updatePrintable()
	{
		$propertiesList = $this->entity->getPropertiesList();
		$propertyData = $propertiesList[$this->source['ID']];

		$codePrintable = $this->source['NAME'] . ' [' . $this->source['CODE'] . ']';
		$this->code = $this->source['ID'];
		$this->codeType = static::getTypeByProperty($this->source);
		$this->isMultiple = ($this->source['MULTIPLE'] == 'Y');

		$values = $this->values;
		$valuesPrintable = [];

		$valuesRestored = $values;
		$valuesUnRestored = [];
		switch ($this->codeType) {
			case static::TYPE_HTML:
				foreach ($values as $value) {
					$valuesPrintable[] = $value['TEXT'];
				}
				break;
			case static::TYPE_STRING:
			case static::TYPE_NUMBER:
			case static::TYPE_DATE:
			case static::TYPE_DATETIME:
			case static::TYPE_SEQUENCE:
			case static::TYPE_MAP_YANDEX:
			case static::TYPE_MAP_GOOGLE:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
				break;
			case static::TYPE_MONEY:
				$valuesPrintable = HelpersLinked::getMoneyPrintable($values);
				break;
			case static::TYPE_SECTION:
			case static::TYPE_SECTION_AUTO:
				$valuesPrintable = HelpersLinked::getSectionsPrintableById($values, $this->source['LINK_IBLOCK_ID']);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_USER_ID:
			case static::TYPE_EMPLOYEE:
				$valuesPrintable = HelpersLinked::getUsersPrintableById($values);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_ELEMENT_CRM:
				$valuesPrintable = HelpersLinked::getCrmElementsPrintable($values, (array) $this->source);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_DIRECTORY:
				$valuesPrintable = HelpersLinked::getElementsHLPrintableById(
					$values,
					$this->source['USER_TYPE_SETTINGS']['TABLE_NAME'],
					true
				);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_ELEMENT:
			case static::TYPE_ELEMENT_AUTO:
				$valuesPrintable = HelpersLinked::getElementsPrintableById($values, $this->source['LINK_IBLOCK_ID']);

			HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_LIST:
				$values = $this->source['VALUE_ENUM_ID'];
				$valuesPrintable = HelpersLinked::getPropertyEnumValues($values);

				HelpersLinked::initValueRestoredAndUnRestored($valuesRestored, $valuesUnRestored, $valuesPrintable, $this->valuesPrintable);
				break;
			case static::TYPE_FILE:
				$fileIds = [];
				foreach ($values as $value) {
					if ($value > 0) {
						$fileIds[] = HelpersFile::getDoubleFileIdByFileId($value);
					}
				}
				$this->isFile = !empty($fileIds);
				$valuesPrintable = HelpersLinked::getFilesPrintableById($fileIds);
				break;
			default:
				foreach ($values as $value) {
					$valuesPrintable[] = $value;
				}
		}

		if (!empty($this->valuesPrintable)) {
			foreach ($this->valuesPrintable as $key => $valuePrintable) {
				if (empty($valuesPrintable[$key])) {
					$valuesPrintable[$key] = $this->valuesPrintable[$key];
				}
			}
		} else if (empty($valuesPrintable)) {
			$valuesPrintable = $values;
		}

		$this->valuesRestored = (array) $valuesRestored;
		$this->valuesUnRestored = (array) $valuesUnRestored;

		$this->codePrintable = $codePrintable;
		$this->valuesPrintable = (array) $valuesPrintable;
	}

	public static function getTypeByProperty($property = []): string
	{
		$type = '';

		if (empty($property['USER_TYPE'])) {
			$type = $property['PROPERTY_TYPE'];
		} else {
			$type = $property['PROPERTY_TYPE'] . ':' . $property['USER_TYPE'];
		}

		return (string) $type;
	}

	public static function getNotTrackedTypes(): array
	{
		return [
			static::TYPE_DISK_FILE,
			static::TYPE_SKU,
			static::TYPE_TOPIC_ID,
			static::TYPE_FILEMAN,
			static::TYPE_ELEMENT_LIST,
			static::TYPE_VIDEO,
			static::TYPE_ELEMENT_XML_ID,
		];
	}

	public static function getLinkedTypes(): array
	{
		return [
			static::TYPE_LIST,
			static::TYPE_ELEMENT,
			static::TYPE_SECTION,
			static::TYPE_USER_ID,
			static::TYPE_SECTION_AUTO,
			static::TYPE_EMPLOYEE,
			static::TYPE_ELEMENT_CRM,
			static::TYPE_ELEMENT_AUTO,
			static::TYPE_DIRECTORY,
		];
	}
}