<?php
namespace GreenAtom\Changelog;

use GreenAtom\ChangeLog\{
	Option as ChangeLogOption,
	Entity\EntityInterface as EntityInterface,
	Orm\ChangelogTable as ChangelogTable,
	Helpers\File as HelpersFile,
	History\History,
	Restore\Analysis,
	Show\Detail
};

use Bitrix\Iblock\{
	ElementTable,
	SectionTable
};
use Bitrix\Main\{
	Error,
	Application,
	FileTable,
	Localization\Loc,
	Engine\CurrentUser
};
use Bitrix\Main\ORM\Data\{
	Result,
	AddResult,
	UpdateResult,
	DeleteResult
};

Loc::loadMessages(__FILE__);

class Changelog
{
	protected EntityInterface $entity;
	protected ChangelogTable $changeLogTable;

	public function __construct(EntityInterface $entity)
	{
		$this->entity = $entity;
		$this->changeLogTable = new ChangelogTable($entity);
	}

	public function saveSnapshot(): Result
	{
		$result = new Result();
		if ($this->entity->isLogged() === false) {
			$result->addError(new Error(Loc::getMessage('GREENATOM_CHANGELOG_ENTITY_DONT_LOGGED')));
			return $result;
		}

		$snapshot = $this->entity->getSnapshot();
		$snapshotLastVersion = $this->changeLogTable->getLastVersionSnapshot();
		$snapshotLastVersion->updatePrintable();
		if (!$snapshot->isEqual($snapshotLastVersion)) {
			// сохраняем новую версию сущности
			$snapshot->setVersion($snapshotLastVersion->getVersion() + 1);
			$result = $snapshot->save();
			if ($result->isSuccess()) {
				// удаляем самую старую запись если превышем лимит
				$this->changeLogTable->deleteFirstVersion();
			}
		} else {
			$result->addError(new Error(Loc::getMessage('GREENATOM_CHANGELOG_ENTITY_DONT_CHANGED')));
		}

		return $result;
	}

	public function getHistory(): History
	{
		return new History($this->entity);
	}

	public function clearHistory()
	{
		$this->changeLogTable->clearHistory();
	}

	public function getAnalizeRestoreToVersion(int $version): Analysis
	{
		return new Analysis($this->entity, $version);
	}

	public function getDetailByVersion($version)
	{
		return new Detail($this->entity, $version);
	}

	public function restoreToVersion(int $version): Result
	{
		$itemNew = $this->changeLogTable->getByVersionSnapshot($version);
		$itemNew->updatePrintable();

		return $this->entity->restoreSnapshot($itemNew);
	}
}