<?php

namespace GreenAtom\ChangeLog;

use Bitrix\Main\Config\Option as BxOption;

class Option
{
	const COUNT_ELEMENT_HISTORY = 'COUNT_ELEMENT_HISTORY';
	const IBLOCK_IDS = 'IBLOCK_IDS';
	const IBLOCK_ELEMENT_FIELDS = 'IBLOCK_ELEMENT_FIELDS';
	const IBLOCK_SECTION_FIELDS = 'IBLOCK_SECTION_FIELDS';

	const COUNT_ELEMENT_HISTORY_DEFAULT = 50;

	public static function getMapByOrmEntity(\Bitrix\Main\ORM\Data\DataManager $entity): array
	{
		$fields = [];

		$ignoredFields = [
			'IBLOCK_ID',
			'RIGHT_MARGIN',
			'DEPTH_LEVEL',
			'SOCNET_GROUP_ID',
			'CREATED_BY',
			'MODIFIED_BY',
			'DATE_CREATE',
			'TIMESTAMP_X',
			'SEARCHABLE_CONTENT',
			'WF_STATUS_ID',
			'WF_PARENT_ELEMENT_ID',
			'WF_NEW',
			'WF_LOCKED_BY',
			'WF_DATE_LOCK',
			'WF_COMMENTS',
			'WF_LOCKED_BY_USER',
			'IN_SECTIONS',
			'TMP_ID',
			'SHOW_COUNTER',
			'SHOW_COUNTER_START',
			'WF_PARENT_ELEMENT',
		];

		foreach ($entity::getMap() as $fieldId => $field) {
			if (in_array($fieldId, $ignoredFields)) {
				continue;
			}

			if (is_array($field)) {
				if (!empty($field['reference']))
					continue;

				$fields[$fieldId] = $field['title'] . ' [' . $fieldId . ']';
			} else if ($field instanceof \Bitrix\Main\ORM\Fields\Field) {
				if ($field instanceof \Bitrix\Main\ORM\Fields\Relations\Relation)
					continue;

				$fields[$field->getName()] = $field->getTitle() . ' [' . $field->getName() . ']';
			}
		}

		return $fields;
	}

	public static function getCountElementHistory(): int
	{
		return (int) BxOption::get(
			'greenatom.changelog',
			static::COUNT_ELEMENT_HISTORY,
			static::COUNT_ELEMENT_HISTORY_DEFAULT
		);
	}

	public static function getIblockIds(): array
	{
		$iblockIds = [];
		$iblockIds = explode(
			',',
			BxOption::get('greenatom.changelog', static::IBLOCK_IDS)
		);

		return $iblockIds;
	}

	public static function getIblockElementFields(): array
	{
		$iblockElementFields = [];
		$iblockElementFields = explode(
			',',
			BxOption::get('greenatom.changelog', static::IBLOCK_ELEMENT_FIELDS, '*')
		);

		return $iblockElementFields;
	}

	public static function getIblockSectionFields(): array
	{
		$iblockSectionFields = [];
		$iblockSectionFields = explode(
			',',
			BxOption::get('greenatom.changelog', static::IBLOCK_SECTION_FIELDS, '*')
		);

		return $iblockSectionFields;
	}
}