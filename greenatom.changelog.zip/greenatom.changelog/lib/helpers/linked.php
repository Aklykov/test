<?php

namespace GreenAtom\ChangeLog\Helpers;

use Bitrix\Main\{FileTable, UserTable};
use Bitrix\Iblock\{SectionTable, ElementTable, PropertyEnumerationTable};
use Bitrix\Highloadblock\HighloadBlockTable;

class Linked
{
	protected static $cache = [];

	/**
	 * Получить печатное представление пользователей по его ИД
	 *
	 * @param array $userIds
	 * @return array
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public static function getUsersPrintableById($userIds): array
	{
		$usersPrintable = [];

		if (!empty($userIds)) {
			$rsUser = UserTable::getList([
				'select' => ['ID', 'SHORT_NAME', 'EMAIL'],
				'filter' => ['ID' => $userIds],
			]);
			while ($user = $rsUser->fetch()) {
				$usersPrintable[$user['ID']] = $user['SHORT_NAME'] . ' (' . $user['EMAIL'] . ')';
			}
		}

		return $usersPrintable;
	}

	/**
	 * Получить печатное представление раздела по его ИД
	 *
	 * @param array $sectionIds
	 * @param int $iblockId
	 * @return array
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public static function getSectionsPrintableById($sectionIds = [], $iblockId = 0): array
	{
		$sectionsPrintable = [];

		if (!empty($sectionIds) && $sectionIds[0] > 0) {
			$rsSection = SectionTable::getList([
				'select' => ['ID', 'NAME'],
				'filter' => [
					'ID' => $sectionIds,
					'IBLOCK_ID' => $iblockId,
				],
			]);
			while ($section = $rsSection->fetch()) {
				$sectionsPrintable[$section['ID']] = $section['NAME'];
			}
		}

		return $sectionsPrintable;
	}

	/**
	 * Получить печатное представление элемента по его ИД
	 *
	 * @param array $elementIds
	 * @param int $iblockId
	 * @return array
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public static function getElementsPrintableById($elementIds = [], $iblockId = 0): array
	{
		$elementsPrintable = [];

		if (!empty($elementIds) && $elementIds[0] > 0) {
			$rsElement = ElementTable::getList([
				'select' => ['ID', 'NAME'],
				'filter' => [
					'ID' => $elementIds,
					'IBLOCK_ID' => $iblockId,
				],
			]);
			while ($element = $rsElement->fetch()) {
				$elementsPrintable[$element['ID']] = $element['NAME'];
			}
		}

		return $elementsPrintable;
	}

	public static function getElementsHLPrintableById($elementHLIds = [], $highloadId = 0, $forIblock = false): array
	{
		$elementsHLPrintable = [];

		if ($forIblock) { // для ИБ
			$hlblock = HighloadBlockTable::getRow(['filter' => ['TABLE_NAME' => $highloadId]]);
			$filterField = 'UF_XML_ID';
		} else { // для UF
			$hlblock = HighloadBlockTable::getRow(['filter' => ['ID' => $highloadId]]);
			$filterField = 'ID';
		}

		if (!empty($elementHLIds) && !empty($elementHLIds[0])) {
			if ($hlblock) {
				$entity = HighloadBlockTable::compileEntity($hlblock); //генерация класса
				$entityClass = $entity->getDataClass();
				$rsElementHL = $entityClass::getList([
					'select' => ['*'],
					'filter' => [$filterField => $elementHLIds]
				]);
				while ($elementHL = $rsElementHL->fetch()) {
					$key = ($forIblock) ? $elementHL['UF_XML_ID'] : $elementHL['ID'];
					if (!empty($elementHL['NAME'])) {
						$elementsHLPrintable[$key] = $elementHL['NAME'];
					} else if (!empty($elementHL['UF_DESCRIPTION'])) {
						$elementsHLPrintable[$key] = $elementHL['UF_DESCRIPTION'];
					} else if (!empty($elementHL['UF_FULL_DESCRIPTION'])) {
						$elementsHLPrintable[$key] = $elementHL['UF_FULL_DESCRIPTION'];
					} else {
						$elementsHLPrintable[$key] = $key;
					}
				}
			}
		}

		return $elementsHLPrintable;
	}

	/**
	 * Получить печатное представление файла по его ИД
	 *
	 * @param array $fileIds
	 * @return array
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public static function getFilesPrintableById($fileIds = []): array
	{
		$filesPrintable = [];

		if (!empty($fileIds) && $fileIds[0] > 0) {
			$rsFile = FileTable::getList([
				'select' => ['ORIGINAL_NAME'],
				'filter' => ['ID' => $fileIds],
			]);
			while ($file = $rsFile->fetch()) {
				$filesPrintable[] = $file['ORIGINAL_NAME'];
			}
		}

		return $filesPrintable;
	}

	public static function getUserfieldEnumValues($userfieldEnumIds = []): array
	{
		$userfieldEnumValues = [];

		if (!empty($userfieldEnumIds) && $userfieldEnumIds[0] > 0) {
			$rsUserFieldEnum = \CUserFieldEnum::GetList(
				['SORT' => 'ASC'],
				['ID' => $userfieldEnumIds],
			);
			while ($userFieldEnum = $rsUserFieldEnum->Fetch()) {
				$userfieldEnumValues[$userFieldEnum['ID']] = $userFieldEnum['VALUE'];
			}
		}

		return $userfieldEnumValues;
	}

	public static function getPropertyEnumValues($propertyEnumIds = []): array
	{
		$propertyEnumValues = [];

		if (!empty($propertyEnumIds) && $propertyEnumIds[0] > 0) {
			$rsPropertyEnumeration = PropertyEnumerationTable::getList([
				'order' => ['SORT' => 'ASC'],
				'select' => ['ID', 'VALUE'],
				'filter' => ['ID' => $propertyEnumIds],
			]);
			while ($propertyEnumeration = $rsPropertyEnumeration->fetch()) {
				$propertyEnumValues[$propertyEnumeration['ID']] = $propertyEnumeration['VALUE'];
			}
		}

		return $propertyEnumValues;
	}

	public static function getMoneyPrintable($money = []): array
	{
		$moneyPrintable = [];

		if (!empty($money) && !empty($money[0])) {
			foreach ($money as $moneyItem) {
				list($price, $currency) = explode('|', $moneyItem);
				$moneyPrintable[] = \CCurrencyLang::CurrencyFormat($price, $currency);
			}
		}

		return $moneyPrintable;
	}

	public static function getCrmStatusesPrintable($crmStatusIds = [], $userField = []): array
	{
		$crmStatusesPrintable = [];

		$rsStatusType = \Bitrix\Crm\UserField\Types\StatusType::getList($userField);
		while ($statusType = $rsStatusType->Fetch()) {
			if (in_array($statusType['ID'], $crmStatusIds)) {
				$crmStatusesPrintable[$statusType['ID']] = $statusType['VALUE'];
			}
		}

		return $crmStatusesPrintable;
	}

	public static function getCrmElementsPrintable($crmElementIds = [], $userField = []): array
	{
		$crmElementsPrintable = [];

		if (!empty($crmElementIds) && !empty($crmElementIds[0])) {
			foreach ($crmElementIds as $crmElementId) {
				list($crmEntityShortName, $crmEntityId) = explode('_', $crmElementId);
				$crmEntityName = \CCrmOwnerTypeAbbr::ResolveName($crmEntityShortName);
				$crmEntityClass = '\\CCrm' . ucfirst(strtolower($crmEntityName));
				if (class_exists($crmEntityClass)) {
					$crmElement = $crmEntityClass::GetList(
						[],
						[
							'CHECK_PERMISSIONS' => 'N',
							'ID' => $crmEntityId,
						],
						['TITLE', 'FULL_NAME']
					)->Fetch();
					if (!empty($crmElement)) {
						$crmElementTitle = !empty($crmElement['TITLE']) ? $crmElement['TITLE'] : $crmElement['FULL_NAME'];
						$crmElementTitle = $crmElementTitle . ' [' . $crmElementId . ']';
						$crmElementsPrintable[$crmElementId] = $crmElementTitle;
					}
				} else {
					$crmElementsPrintable[$crmElementId] = $crmElementId;
				}
			}
		}

		return $crmElementsPrintable;
	}

	public static function initValueRestoredAndUnRestored(&$valuesRestored, &$valuesUnRestored, $valuesPrintable, $thisValuesPrintable)
	{
		$valuesRestored = [];
		$thisValuesPrintable = empty($thisValuesPrintable) ? $valuesPrintable : $thisValuesPrintable;
		foreach ($thisValuesPrintable as $key => $valuePrintable) {
			if (isset($valuesPrintable[$key])) {
				$valuesRestored[] = $key;
			} else if (!empty($valuePrintable)) {
				$valuesUnRestored[$key] = $valuePrintable;
			}
		}
	}
}