<?php

namespace GreenAtom\ChangeLog\Helpers;

use Bitrix\Main\FileTable;
use GreenAtom\Changelog\Entity\EntityInterface as EntityInterface;
use GreenAtom\Changelog\Orm\ChangelogTable as ChangelogTable;
use GreenAtom\ChangeLog\EntityField\Field;
use GreenAtom\ChangeLog\EntityField\Userfield;
use GreenAtom\ChangeLog\Snapshot;

class File
{
	protected EntityInterface $entity;

	public function __construct(EntityInterface $entity)
	{
		$this->entity = $entity;
	}

	public static function checkCreateDoubleForFileIds(array $fileIds = [])
	{
		foreach ($fileIds as $fileId) {
			static::checkCreateDoubleForFileId($fileId);
		}
	}

	protected static function checkCreateDoubleForFileId($fileId = 0)
	{
		// есть ли уже дубль к этому файлу?
		$doubleFileId = static::getDoubleFileIdByFileId($fileId);
		if ($doubleFileId === 0) {
			$fileData = \CFile::MakeFileArray($fileId);
			unset($fileData['ID']);
			$fileData['MODULE_ID'] = 'greenatom.changelog';
			$fileData['external_id'] = $fileId;
			$fileData['tmp_name'] = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($fileId);
			$doubleFileId = \CFile::SaveFile($fileData, $fileData['MODULE_ID'], false, false, '', false);
		}
	}

	public static function getMd5ByFileId($fileId = 0): string
	{
		$doubleFileId = static::getDoubleFileIdByFileId($fileId);
		$doubleFileId = ($doubleFileId > 0) ? $doubleFileId : $fileId;
		$path = $_SERVER['DOCUMENT_ROOT'] . \CFile::GetPath($doubleFileId);

		return md5(file_get_contents($path));
	}

	public static function getDoubleFileIdByFileId($fileId = 0): int
	{
		return (int) \Bitrix\Main\FileTable::getRow([
			'select' => ['ID'],
			'filter' => [
				'=MODULE_ID' => 'greenatom.changelog',
				'=EXTERNAL_ID' => $fileId,
			],
		])['ID'];
	}

	public static function checkDeleteDoubleForFileIds(string $entity, array $fileIdsDeleted = [])
	{
		$fileIdsAll = [];
		$rsItem = ChangelogTable::getList([
			'select' => ['FILE_IDS'],
			'filter' => [
				'ENTITY' => $entity,
			],
		]);
		while ($item = $rsItem->fetch()) {
			$fileIds = unserialize($item['FILE_IDS']);
			if (!empty($fileIds)) {
				$fileIdsAll = array_merge($fileIdsAll, $fileIds);
			}
		}
		$fileIdsAll = array_unique($fileIdsAll);

		foreach ($fileIdsDeleted as $fileIdDeleted) {
			if (in_array($fileIdDeleted, $fileIdsAll) === false) {
				$fileDoubleIdDeleted = static::getDoubleFileIdByFileId($fileIdDeleted);
				if ($fileDoubleIdDeleted > 0) {
					\CFile::Delete($fileDoubleIdDeleted);
				}
			}
		}
	}

	public function isExistByFileId($fileId = 0): bool
	{
		return (bool) \Bitrix\Main\FileTable::getCount([
			'ID' => $fileId,
		]);
	}
}