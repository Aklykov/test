<?php

namespace GreenAtom\ChangeLog\Handlers;

use GreenAtom\ChangeLog\Changelog;
use GreenAtom\ChangeLog\Entity\IblockElement as EntityIblockElement;
use GreenAtom\ChangeLog\Entity\IblockSection as EntityIblockSection;

class Iblock
{
	public static function onAfterIBlockElementAdd(&$element)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		static::saveElementHistory($element);
	}

	public static function onAfterIBlockElementUpdate(&$element)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		static::saveElementHistory($element);
	}

	protected static function saveElementHistory($element)
	{
		if ($element['ID'] > 0 && $element['IBLOCK_ID']) {
			$entity = new EntityIblockElement($element['ID'], $element['IBLOCK_ID']);
			if ($entity->isLogged()) {
				$changelog = new Changelog($entity);
				$changelog->saveSnapshot();
			}
		}
	}

	public static function onAfterIBlockElementDelete($element)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		if ($element['ID'] > 0 && $element['IBLOCK_ID']) {
			$entity = new EntityIblockElement($element['ID'], $element['IBLOCK_ID']);
			if ($entity->isLogged()) {
				$changelog = new Changelog($entity);
				$changelog->clearHistory();
			}
		}
	}

	public static function onAfterIBlockSectionAdd(&$section)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		static::saveSectionHistory($section);
	}

	public static function onAfterIBlockSectionUpdate(&$section)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		static::saveSectionHistory($section);
	}

	protected static function saveSectionHistory($section)
	{
		if ($section['ID'] > 0 && $section['IBLOCK_ID']) {
			$entity = new EntityIblockSection($section['ID'], $section['IBLOCK_ID']);
			if ($entity->isLogged()) {
				$changelog = new Changelog($entity);
				$changelog->saveSnapshot();
			}
		}
	}

	public static function onAfterIBlockSectionDelete($section)
	{
		if ($section['ID'] > 0 && $section['IBLOCK_ID']) {
			$entity = new EntityIblockSection($section['ID'], $section['IBLOCK_ID']);
			if ($entity->isLogged()) {
				$changelog = new Changelog($entity);
				$changelog->clearHistory();
			}
		}
	}
}