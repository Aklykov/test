<?php

namespace GreenAtom\ChangeLog\Handlers;

class Handler
{
	/** @var bool $isIgnoreEvent */
	protected static $isIgnoreEvent = false;

	public static function setIgnoreEvent()
	{
		static::$isIgnoreEvent = true;
	}

	public static function unsetIgnoreEvent()
	{
		static::$isIgnoreEvent = false;
	}

	public static function isIgnoreEvent(): bool
	{
		return static::$isIgnoreEvent;
	}
}