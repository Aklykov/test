<?php

namespace GreenAtom\ChangeLog\Handlers;

use GreenAtom\ChangeLog\Entity\EntityInterface;
use GreenAtom\ChangeLog\Entity\IblockElement;
use GreenAtom\ChangeLog\Entity\IblockSection;
use Bitrix\Main\Localization\Loc;

class Main
{
	/**
	 * Ввыод ссылки в списке сущности
	 *
	 * @param $uiList \CAdminUiList
	 */
	public static function onAdminListDisplay(&$uiList)
	{
		/** @var \CAdminListRow $listRow */
		foreach ($uiList->aRows as $listRow) {
			if ($listRow->arRes['TYPE'] == 'S') {
				$entity = new IblockSection($listRow->arRes['ID'], $listRow->arRes['IBLOCK_ID']);
			} else if ($listRow->arRes['TYPE'] == 'E') {
				$entity = new IblockElement($listRow->arRes['ID'], $listRow->arRes['IBLOCK_ID']);
			}

			if ($entity instanceof EntityInterface && $entity->isLogged()) {
				$listRow->aActions[] = [
					'ID' => 'greenatom.changelog_history_link',
					'TEXT' => Loc::getMessage('GREENATOM_CHANGELOG_HANDLERS_MAIN_MENU_TEXT'),
					'LINK' => $entity->getUrlAdminHistory(),
				];
			}
		}
	}

	/**
	 * Вывод ссылки в деталке сущности
	 *
	 * @param $items
	 */
	public static function onAdminContextMenuShow(&$items)
	{
		$request = \Bitrix\Main\Application::getInstance()->getContext()->getRequest();
		$url = $request->getRequestedPage();
		$queryList = $request->getQueryList()->toArray();

		$urls = [
			'/bitrix/admin/iblock_element_edit.php',
			'/bitrix/admin/iblock_section_edit.php',
		];
		if (in_array($url, $urls) && $queryList['IBLOCK_ID'] > 0 && $queryList['ID'] > 0) {
			if ($url == '/bitrix/admin/iblock_element_edit.php') {
				$entity = new IblockElement($queryList['ID'], $queryList['IBLOCK_ID']);
			} else if ($url == '/bitrix/admin/iblock_section_edit.php') {
				$entity = new IblockSection($queryList['ID'], $queryList['IBLOCK_ID']);
			}
			if ($entity instanceof EntityInterface && $entity->isLogged()) {
				$items[] = [
					'TEXT' => Loc::getMessage('GREENATOM_CHANGELOG_HANDLERS_MAIN_MENU_TEXT'),
					'TITLE' => Loc::getMessage('GREENATOM_CHANGELOG_HANDLERS_MAIN_MENU_TITLE'),
					'LINK' => $entity->getUrlAdminHistory(),
				];
			}
		}
	}
}