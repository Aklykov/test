<?php

namespace GreenAtom\ChangeLog\Handlers;
use Bitrix\Main\Loader;
use GreenAtom\ChangeLog\Entity\IblockElement;
use GreenAtom\ChangeLog\Entity\IblockSection;
use GreenAtom\ChangeLog\Changelog;

class Attributes
{
	public static function onChangeEntityAttributes($entityAttributes)
	{
		if (Handler::isIgnoreEvent()) {
			return false;
		}

		if (Loader::includeModule('greenatom.attributes')) {
			if ($entityAttributes instanceof \GreenAtom\Attributes\Entity\IblockElement) {
				$entity = new IblockElement(
					$entityAttributes->getElementId(),
					$entityAttributes->getIblockId()
				);
				$changelog = new Changelog($entity);
				$result = $changelog->saveSnapshot();
			} else if ($entityAttributes instanceof \GreenAtom\Attributes\Entity\IblockSection) {
				$entity = new IblockSection(
					$entityAttributes->getSectionId(),
					$entityAttributes->getIblockId()
				);
				$changelog = new Changelog($entity);
				$result = $changelog->saveSnapshot();
			}
		}
	}
}