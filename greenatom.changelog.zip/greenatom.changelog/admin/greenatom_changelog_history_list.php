<?php
define('NO_KEEP_STATISTIC', true);
define('NO_AGENT_STATISTIC', true);
define('STOP_STATISTICS', true);
define('LANGUAGE_ID', 'ru');

use Bitrix\Main\Localization\Loc;
use Bitrix\Main\{
	Application,
	Loader,
	Result,
	Error
};
use GreenAtom\ChangeLog\Entity\{
	IblockElement,
	IblockSection
};
use GreenAtom\ChangeLog\Changelog;
use GreenAtom\ChangeLog\Orm\ChangelogTable;
use GreenAtom\ChangeLog\Entity\EntityInterface;

require_once($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_before.php');
/** @global CMain $APPLICATION */
/** @global CDatabase $DB */
/** @global CUser $USER */
global $APPLICATION;
$RIGHT = $APPLICATION->GetGroupRight('greenatom.changelog');
if ($RIGHT == 'D') {
	$APPLICATION->AuthForm(GetMessage('ACCESS_DENIED'));
}
Loc::loadMessages(__FILE__);

Loader::includeModule('greenatom.changelog');
$result = new Result();
$request = Application::getInstance()->getContext()->getRequest();
$get = $request->getQueryList()->toArray();
$pageCurrent = $request->getRequestedPage() . '?ENTITY=' . $get['ENTITY'];

$entity = ChangelogTable::getEntityByEntity($get['ENTITY']);
if ($entity instanceof EntityInterface) {
	$changelog = new Changelog($entity);
	if ($get['GET_DETAIL_VERSION'] == 'Y' && $get['VERSION'] > 0) {
		$APPLICATION->RestartBuffer();
		$detail = $changelog->getDetailByVersion($get['VERSION']);
		$detail->printDebugDetailTable();
		die();
	} else if ($get['RESTORE'] == 'Y' && $get['VERSION'] > 0) {
		// если восстановление
		$resultRestore = $changelog->restoreToVersion($get['VERSION']);
		if ($resultRestore->isSuccess()) {
			LocalRedirect($pageCurrent);
			die();
		} else {
			foreach ($resultRestore->getErrorMessages() as $errorMessage) {
				$result->addError(new Error($errorMessage));
			}
		}
	} else {
		// выводим список
		$history = $changelog->getHistory();
		$result->setData(['items' => $history->getItems()]);
	}

	$APPLICATION->SetTitle(
		Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_TITLE', [
			'#NAME#' => $entity->getName()
		])
	);
} else {
	$result->addError(new Error(Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_ENTITY_NOT_FOUND')));
}

require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_admin_after.php');

CJSCore::Init(['jquery']);
\Bitrix\Main\UI\Extension::load('ui.bootstrap4');
\Bitrix\Main\UI\Extension::load("ui.dialogs.messagebox");
?>
<?php if ($result->isSuccess()):?>
	<table class="table table-bordered table-hover greenatom-changelog-history">
		<thead>
			<tr>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_VERSION')?></th>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_DATECHANGE')?></th>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_AUTHOR')?></th>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_CHANGES')?></th>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_RESTRICTION')?></th>
				<th scope="col" class="text-center align-top"><?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_ACTIONS')?></th>
			</tr>
		</thead>
		<tbody>
		<?$items = $result->getData()['items'];?>
		<?foreach ($items as $key => $item):?>
			<tr>
				<th scope="row" class="text-center align-top"><?=$item['version']?></th>
				<td class="text-center align-top"><?=$item['dateChange']?></td>
				<td class="text-center align-top"><?=$item['author']?></td>
				<td class="text-left align-top">
					<?foreach ($item['differences'] as $difference):?>
						<table class="greenatom-changelog-difference">
							<tr><th colspan="2"><?=$difference['name']?></th></tr>
							<tr>
								<td>
									<b>Было:</b><br>
									<?=implode('<br><br>', $difference['valueOld']);?><br><br>
								</td>
								<td>
									<b>Стало:</b><br>
									<?=implode('<br><br>', $difference['valueNew']);?><br><br>
								</td>
							</tr>
						</table>
					<?endforeach;?>
				</td>
				<td class="text-left align-top">
					<?foreach ($item['alerts'] as $alert):?>
						<?=$alert['text']?><br><br>
					<?endforeach;?>
				</td>
				<td class="text-center align-top">
					<?if ($key > 0):?>
						<a href="<?=$pageCurrent?>&RESTORE=Y&VERSION=<?=$item['version']?>">
							<?=Loc::getMessage('GREENATOM_CHANGELOG_ADMIN_HISTORY_LIST_RESTORE')?>
						</a>
						<br><br>
					<?endif;?>
					<a href="#" class="greenatom-changelog-showdetail" data-version="<?=$item['version']?>">Подробней</a>
				</td>
			</tr>
		<?endforeach;?>
		</tbody>
	</table>
<?php else:?>
	<?php \CAdminMessage::ShowMessage([
		'MESSAGE' => implode('<br>', $result->getErrorMessages()),
		'TYPE' => 'ERROR'
	]);?>

	<?php if ($get['RESTORE'] == 'Y' && $get['VERSION'] > 0):?>
		<a href="<?=$pageCurrent?>">Вернутся к списку версий</a>
	<?php endif;?>
<?php endif;?>

<!-- Modal -->
<div class="modal fade" id="modalDetailVersion" tabindex="-1" role="dialog" aria-labelledby="modalDetailVersionTitle" aria-hidden="true">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<h5 class="modal-title" id="modalDetailVersionTitle">Детальный показ версии №39</h5>
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body" id="modalDetailVersionBody"></div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Закрыть</button>
			</div>
		</div>
	</div>
</div>

<style>
	.greenatom-changelog-history {
		background: white;
	}
	.greenatom-changelog-history tr th:nth-child(4) {
		width: 50%;
	}
    .greenatom-changelog-history tr td:nth-child(4) {
        width: 50%;
    }

	.greenatom-changelog-difference {
		width: 100%;
        border: 1px solid transparent;
        border-collapse: collapse;
	}
    .greenatom-changelog-difference tr {
        border: 1px solid transparent;
        border-collapse: collapse;
        vertical-align: top;
    }
    .greenatom-changelog-difference td {
	    width: 50%;
        border: 1px solid transparent;
        border-bottom-color: #e5e5e5;
        border-collapse: collapse;
        vertical-align: top;
    }
    #modalDetailVersion .modal-dialog {
        max-width: 80%;
    }
</style>
<script>
	$(document).ready(function(){
		let modalDetailVersion = $('#modalDetailVersion');
		let modalDetailVersionTitle = $('#modalDetailVersionTitle');
		let modalDetailVersionBody = $('#modalDetailVersionBody');

		$('.greenatom-changelog-showdetail').click(function(event){
			event.preventDefault();
			let version = $(this).data('version');
			$.ajax({
				url: '<?=$pageCurrent?>&GET_DETAIL_VERSION=Y&VERSION=' + version,
				type: 'GET',
				success: function(html)
				{
					modalDetailVersionTitle.html('Версия № ' + version);
					modalDetailVersionBody.html(html);
					modalDetailVersion.modal();
				},
				dataType: 'html'
			});
		});
	});
</script>

<?php require($_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/epilog_admin.php');?>
