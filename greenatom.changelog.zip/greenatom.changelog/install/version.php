<?php
$arModuleInfo = array(
	'VERSION' => '1.0.0',
	'VERSION_DATE' => '2022-12-02'
);
return $arModuleInfo;
