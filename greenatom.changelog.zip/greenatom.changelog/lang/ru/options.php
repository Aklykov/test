<?
$MESS['GREENATOM_CHANGELOG_OPTIONS_SETTINGS'] = 'Настройки';
$MESS['GREENATOM_CHANGELOG_OPTIONS_DEFAULT'] = 'По умолчанию';
$MESS['GREENATOM_CHANGELOG_OPTIONS_APPLY'] = 'Применить';
$MESS['GREENATOM_CHANGELOG_OPTIONS_COUNT_ELEMENT_HISTORY'] = 'Кол-во хранимых изменений';
$MESS['GREENATOM_CHANGELOG_OPTIONS_IBLOCK_IDS'] = 'Инфоблоки, которые будут логироваться';
$MESS['GREENATOM_CHANGELOG_OPTIONS_IBLOCK_ELEMENT_FIELDS'] = 'Поля элементов инфоблока, которые будут логироваться';
$MESS['GREENATOM_CHANGELOG_OPTIONS_IBLOCK_SECTION_FIELDS'] = 'Поля разделов инфоблока, которые будут логироваться';