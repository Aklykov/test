<?
$MESS['GREENATOM_CHANGELOG_HANDLERS_MAIN_MENU_TITLE'] = 'Просмотр истории (greenatom.changelog)';
$MESS['GREENATOM_CHANGELOG_HANDLERS_MAIN_MENU_TEXT'] = 'Просмотр истории (greenatom.changelog)';