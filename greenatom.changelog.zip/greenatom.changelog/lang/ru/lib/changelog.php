<?php
$MESS['GREENATOM_CHANGELOG_ENTITY_DONT_LOGGED'] = 'Данная сущность не логгируется';
$MESS['GREENATOM_CHANGELOG_ENTITY_DONT_CHANGED'] = 'Изменений с последней версией не обнаруженно';