<?php
$arModuleInfo = array(
	'VERSION' => '2.0.0',
	'VERSION_DATE' => '2023-03-15'
);
return $arModuleInfo;
