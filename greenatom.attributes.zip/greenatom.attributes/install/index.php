<?php

use \Bitrix\Main\ModuleManager;
use \Bitrix\Main\EventManager;
use \Bitrix\Main\Loader;
use \Bitrix\Main\Application;
use \Bitrix\Main\Localization\Loc;
use \GreenAtom\Attributes\Orm\AttributeTable;
use \GreenAtom\Attributes\Entity\{
	IblockElement as EntityIblockElement,
	IblockSection as EntityIblockSection,
	HighloadElement as EntityHighloadElement,
	User as EntityUser
};

Loc::loadMessages(__FILE__);
class greenatom_attributes extends \CModule
{
	function __construct()
	{
		$arModuleInfo = array();
		$arModuleInfo = include(__DIR__ . '/version.php');

		$this->MODULE_ID = 'greenatom.attributes';
		$this->MODULE_VERSION = $arModuleInfo['VERSION'];
		$this->MODULE_VERSION_DATE = $arModuleInfo['VERSION_DATE'];
		$this->MODULE_NAME = Loc::GetMessage('GREENATOM_ATTRIBUTES_MODULE_NAME');
		$this->MODULE_DESCRIPTION = Loc::GetMessage('GREENATOM_ATTRIBUTES_MODULE_DESCRIPTION');

		$this->PARTNER_NAME = Loc::GetMessage('GREENATOM_ATTRIBUTES_PARTNER_NAME');
		$this->PARTNER_URI = Loc::GetMessage('GREENATOM_ATTRIBUTES_PARTNER_URI');

		$this->MODULE_SORT = 2;
		$this->MODULE_GROUP_RIGHTS = 'Y';
	}

	/**
	 * Определяем где лежит модуль (полный или относительный)
	 *
	 * @param bool $notDocumentRoot - нужен относительный путь? (по умолчанию-полный)
	 * @return string
	 */
	function getPath($notDocumentRoot=false)
	{
		if($notDocumentRoot)
			return str_ireplace(Application::getDocumentRoot(), '', dirname(__DIR__));
		else
			return dirname(__DIR__);
	}

	/**
	 * Установка модуля
	 */
	function DoInstall()
	{
		global $APPLICATION;
        ModuleManager::registerModule($this->MODULE_ID);
        Loader::includeModule($this->MODULE_ID);

        $this->InstallDB();
        $this->InstallEvents();

		$APPLICATION->IncludeAdminFile(
			Loc::getMessage('GREENATOM_ATTRIBUTES_INSTALL_TITLE'),
			$this->getPath().'/install/step.php'
		);
	}

	/**
	 * Удаление модуля
	 */
	function DoUninstall()
	{
		global $APPLICATION;
		Loader::includeModule($this->MODULE_ID);
		$arGet = Application::getInstance()->getContext()->getRequest()->getQueryList()->toArray();

		if (!isset($arGet['step'])) {
			$APPLICATION->IncludeAdminFile(
				Loc::getMessage('GREENATOM_ATTRIBUTES_UNINSTALL_TITLE'),
				$this->getPath().'/install/unstep1.php'
			);
		} elseif ($arGet['step'] == 2) {
			Loader::includeModule($this->MODULE_ID);
			if ($arGet['savedata'] != 'Y') {
				$this->UnInstallDB();
			}

			$this->UnInstallEvents();
			ModuleManager::UnRegisterModule($this->MODULE_ID);

			$APPLICATION->IncludeAdminFile(
				Loc::getMessage('GREENATOM_ATTRIBUTES_UNINSTALL_TITLE'),
				$this->getPath().'/install/unstep2.php'
			);
		}
	}

	function InstallDB()
	{
		// создаем таблицу
		$tableName = AttributeTable::getTableName();
		if (!Application::getConnection()->isTableExists($tableName)) {
			\Bitrix\Main\Entity\Base::getInstance(AttributeTable::class)->createDBTable();
		}
	}

	function UnInstallDB()
	{
		// удаляем таблицу
		$tableName = AttributeTable::getTableName();
		if (Application::getConnection()->isTableExists($tableName)) {
			Application::getConnection()->dropTable($tableName);
		}
	}

	function getEvents()
	{
		return [
			// события на удаления сущностей
			[
				'iblock',
				'OnAfterIBlockElementDelete',
				$this->MODULE_ID,
				EntityIblockElement::class,
				'onAfterDeleteEntityHandler',
			],
			[
				'iblock',
				'OnAfterIBlockSectionDelete',
				$this->MODULE_ID,
				EntityIblockSection::class,
				'onAfterDeleteEntityHandler',
			],
			[
				'main',
				'OnAfterUserDelete',
				$this->MODULE_ID,
				EntityUser::class,
				'onAfterDeleteEntityHandler',
			],

			// события на показ атрибутов в админке
			[
				'main',
				'OnBeforeProlog',
				$this->MODULE_ID,
				\GreenAtom\Attributes\Tab\Event::class,
				'onAdminTabControlSave',
			],
			[
				'main',
				'OnAdminTabControlBegin',
				$this->MODULE_ID,
				\GreenAtom\Attributes\Tab\Event::class,
				'onAdminTabControlShow',
			],
		];
	}

	function InstallEvents()
	{
		foreach (self::getEvents() as $event) {
			EventManager::getInstance()->registerEventHandler(
				$event[0],
				$event[1],
				$event[2],
				$event[3],
				$event[4],
			);
		}
	}

	function UnInstallEvents()
	{
		foreach (self::getEvents() as $event) {
			EventManager::getInstance()->unRegisterEventHandler(
				$event[0],
				$event[1],
				$event[2],
				$event[3],
				$event[4],
			);
		}
	}
}
