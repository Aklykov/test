<?php

namespace GreenAtom\Attributes\Tab;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use GreenAtom\Attributes\Entity\Base as Entity;

Loc::loadMessages(__FILE__);

class Tab
{
	const NAME_INPUT = 'greenatom_attributes';

	protected Entity $entity;

	public function __construct(Entity $entity)
	{
		$this->entity = $entity;

		$request = Application::getInstance()->getContext()->getRequest();
	}

	public function getTab(): array
	{
		return [
			'DIV' => 'greenatom_attributes',
			'SORT' => 999,
			'TAB' => 'Атрибуты (greenatom.attributes)',
			'TITLE' => 'Атрибуты (greenatom.attributes)',
			'CONTENT' => $this->getContent(),
		];
	}

	protected function getContent(): string
	{
		$attributes = $this->getAttributes();

		\CJSCore::Init(['jquery']);
		ob_start();
		?>
		<?php foreach ($attributes as $attrKey => $attrValue):?>
			<tr>
				<td width="40%"><?=$attrKey?>:</td>
				<td width="60%"><input type="text" name="greenatom_attributes[values][<?=$attrKey?>]" value="<?=$attrValue?>"></td>
			</tr>
		<?php endforeach;?>
		<tr>
			<td width="40%"><input type="text" name="greenatom_attributes[names][]" placeholder="Имя атрибута" class="greenatom_attributes_name"></td>
			<td width="60%"><input type="text" name="greenatom_attributes[values][]" placeholder="Значение атрибута" class="greenatom_attributes_value"></td>
		</tr>
		<tr>
			<td width="40%"><input type="text" name="greenatom_attributes[names][]" placeholder="Имя атрибута" class="greenatom_attributes_name"></td>
			<td width="60%"><input type="text" name="greenatom_attributes[values][]" placeholder="Значение атрибута" class="greenatom_attributes_value"></td>
		</tr>
		<tr class="greenatom_attributes_tr_add">
			<td width="40%">&nbsp;</td>
			<td width="60%"><input type="button" value="Добавить атрибут" class="greenatom_attributes_add"></td>
		</tr>
		<script>
			$(document).ready(function(){
				let $attrtable = $('#greenatom_attributes');
				$attrtable.on('input', '.greenatom_attributes_name', function(event){
					let attrName = $(this).val();
					let inputName = 'greenatom_attributes[values]['+attrName+']';
					$(this).closest('tr').find('.greenatom_attributes_value').attr('name', inputName);
				});
				$attrtable.on('click', '.greenatom_attributes_add', function(event){
					let html = '';
					html += '<tr>';
					html += '<td width="40%" class="adm-detail-content-cell-l"><input type="text" name="greenatom_attributes[names][]" placeholder="Имя атрибута" class="greenatom_attributes_name"></td>';
					html += '<td width="60%" class="adm-detail-content-cell-r"><input type="text" name="greenatom_attributes[values][]" placeholder="Значение атрибута" class="greenatom_attributes_value"></td>';
					html += '</tr>';
					$(html).insertBefore('.greenatom_attributes_tr_add');
				});
			});
		</script>
		<?php
		$html = ob_get_clean();

		return $html;
	}

	protected function getAttributes(): array
	{
		$attributes = [];

		$result = $this->entity->get();
		if ($result->isSuccess()) {
			$attributes = $result->getData();
		}

		return $attributes;
	}
}