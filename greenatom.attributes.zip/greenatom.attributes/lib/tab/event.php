<?php

namespace GreenAtom\Attributes\Tab;
use Bitrix\Main\Loader;
use Bitrix\Main\Application;
use GreenAtom\Attributes\Entity\{
	Base,
	User,
	HighloadElement,
	IblockElement,
	IblockSection,
};

class Event
{
	/**
	 * Событие для вывода таба с атрибутами в админке
	 *
	 * @param CAdminTabControl $form
	 */
	public static function onAdminTabControlShow(&$form)
	{
		$request = Application::getInstance()->getContext()->getRequest();
		$page = $request->getRequestedPage();
		$data = $request->getQueryList()->toArray() + $request->getPostList()->toArray();

		$entity = false;
		switch ($page)
		{
			case '/bitrix/admin/user_edit.php':
				if ($data['ID'] > 0) {
					$entity = new User($data['ID']);
				}
				break;
			case '/bitrix/admin/highloadblock_row_edit.php':
				if ($data['ENTITY_ID'] > 0 && $data['ID'] > 0) {
					$entity = new HighloadElement($data['ID'], $data['ENTITY_ID']);
				}
				break;
			case '/bitrix/admin/iblock_element_edit.php':
				if ($data['IBLOCK_ID'] > 0 && $data['ID'] > 0) {
					$entity = new IblockElement($data['ID'], $data['IBLOCK_ID']);
				}
				break;
			case '/bitrix/admin/iblock_section_edit.php':
				if ($data['IBLOCK_ID'] > 0 && $data['ID'] > 0) {
					$entity = new IblockSection($data['ID'], $data['IBLOCK_ID']);
				}
				break;
		}
		if ($entity instanceof Base) {
			$tab = new Tab($entity);
			$form->tabs[] = $tab->getTab();
		}
	}

	/**
	 * Событие для сохранения таба атрибутов в админке
	 */
	public static function onAdminTabControlSave()
	{
		$request = Application::getInstance()->getContext()->getRequest();

		if ($request->getRequestMethod() != 'POST') {
			return;
		}

		$page = $request->getRequestedPage();
		$data = $request->getQueryList()->toArray() + $request->getPostList()->toArray();

		$entity = false;
		switch ($page)
		{
			case '/bitrix/admin/user_edit.php':
				if ($data['ID'] > 0) {
					$entity = new User($data['ID']);
				}
				break;
			case '/bitrix/admin/highloadblock_row_edit.php':
				if ($data['ENTITY_ID'] > 0 && $data['ID'] > 0) {
					$entity = new HighloadElement($data['ID'], $data['ENTITY_ID']);
				}
				break;
			case '/bitrix/admin/iblock_element_edit.php':
				if ($data['IBLOCK_ID'] > 0 && $data['ID'] > 0) {
					$entity = new IblockElement($data['ID'], $data['IBLOCK_ID']);
				}
				break;
			case '/bitrix/admin/iblock_section_edit.php':
				if ($data['IBLOCK_ID'] > 0 && $data['ID'] > 0) {
					$entity = new IblockSection($data['ID'], $data['IBLOCK_ID']);
				}
				break;
		}
		if ($entity instanceof Base) {
			$entity->saveAll($data[Tab::NAME_INPUT]['values']);
		}
	}
}