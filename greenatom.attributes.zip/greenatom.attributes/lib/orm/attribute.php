<?php

namespace GreenAtom\Attributes\Orm;

use Bitrix\Main,
	Bitrix\Main\Localization\Loc,
	Bitrix\Main\Config\Option,
	Bitrix\Main\ORM\Data\DataManager,
	Bitrix\Main\ORM\Fields\ScalarField,
	Bitrix\Main\ORM\Fields\IntegerField,
	Bitrix\Main\ORM\Fields\StringField,
	Bitrix\Main\ORM\Fields\Relations\Reference,
	Bitrix\Main\ORM\Fields\EnumField,
	Bitrix\Main\ORM\Fields\DatetimeField,
	Bitrix\Main\ORM\Fields\TextField;

Loc::loadMessages(__FILE__);

class AttributeTable extends Main\Entity\DataManager
{
	/**
	 * Returns DB table name for entity.
	 *
	 * @return string
	 */
	public static function getTableName()
	{
		return 'greenatom_attributes_attributes';
	}

	/**
	 * Returns entity map definition.
	 *
	 * @return array
	 */
	public static function getMap()
	{
		return [
			'ID' => new IntegerField('ID', [
				'primary' => true,
				'autocomplete' => true,
				'title' => 'ID',
			]),
			'ENTITY' => new StringField('ENTITY', [
				'required' => true,
				'title' => 'Сущность',
			]),
			'TITLE' => new StringField('TITLE', [
				'required' => true,
				'title' => 'Имя атрибута',
			]),
			'VALUE' => new StringField('VALUE', [
				'required' => true,
				'title' => 'Значение атрибута',
			]),
		];
	}
}

