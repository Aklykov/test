<?php

namespace GreenAtom\Attributes\Entity;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Error;
use Bitrix\Main\ORM\Data\Result;

Loc::loadMessages(__FILE__);

class IblockElement extends Base
{
	/** @var int ИД элемента инфоблока */
	protected int $elementId;

	/** @var int ИД инфоблока */
	protected int $iblockId;

	public function __construct(int $elementId, int $iblockId)
	{
		$this->elementId = $elementId;
		$this->iblockId = $iblockId;

		$this->entity = 'IBLOCK_' . $this->iblockId . '_ELEMENT_' . $this->elementId;
	}

	public function getElementId()
	{
		return $this->elementId;
	}

	public function getIblockId()
	{
		return $this->iblockId;
	}

	protected function checkExistEntity(): Result
	{
		Loader::includeModule('iblock');
		$result = new Result();

		$isExist = (bool) \Bitrix\Iblock\ElementTable::getList([
			'select' => ['ID'],
			'filter' => [
				'=ID' => $this->elementId,
				'=IBLOCK_ID' => $this->iblockId,
			],
			'limit' => 1,
			'count_total' => true,
		])->getSelectedRowsCount();
		if (!$isExist) {
			$result->addError(
				new Error(
					Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_DONT_EXIST_ENTITY', [
						'#ID#' => $this->elementId,
						'#IBLOCK_ID#' => $this->iblockId,
					])
				)
			);
		}

		return $result;
	}

	public static function onAfterDeleteEntityHandler($fields = [])
	{
		$objEntity = new self($fields['ID'], $fields['IBLOCK_ID']);
		$objEntity->deleteAll();
	}
}
