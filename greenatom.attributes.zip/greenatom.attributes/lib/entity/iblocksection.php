<?php

namespace GreenAtom\Attributes\Entity;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Error;
use Bitrix\Main\ORM\Data\Result;

Loc::loadMessages(__FILE__);

class IblockSection extends Base
{
	/** @var int ИД раздела инфоблока */
	protected int $sectionId;

	/** @var int ИД инфоблока */
	protected int $iblockId;

	public function __construct(int $sectionId, int $iblockId)
	{
		$this->sectionId = $sectionId;
		$this->iblockId = $iblockId;

		$this->entity = 'IBLOCK_' . $this->iblockId . '_SECTION_' . $this->sectionId;
	}

	public function getSectionId()
	{
		return $this->sectionId;
	}

	public function getIblockId()
	{
		return $this->iblockId;
	}

	protected function checkExistEntity(): Result
	{
		Loader::includeModule('iblock');
		$result = new Result();

		$isExist = (bool) \Bitrix\Iblock\SectionTable::getList([
			'select' => ['ID'],
			'filter' => [
				'=ID' => $this->sectionId,
				'=IBLOCK_ID' => $this->iblockId,
			],
			'limit' => 1,
			'count_total' => true,
		])->getSelectedRowsCount();
		if (!$isExist) {
			$result->addError(
				new Error(
					Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_DONT_EXIST_ENTITY', [
						'#ID#' => $this->sectionId,
						'#IBLOCK_ID#' => $this->iblockId,
					])
				)
			);
		}

		return $result;
	}

	public static function onAfterDeleteEntityHandler($fields = [])
	{
		$objEntity = new self($fields['ID'], $fields['IBLOCK_ID']);
		$objEntity->deleteAll();
	}
}
