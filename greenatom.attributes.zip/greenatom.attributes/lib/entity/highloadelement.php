<?php

namespace GreenAtom\Attributes\Entity;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Error;
use Bitrix\Main\ORM\Data\Result;
use Bitrix\Highloadblock as HL;

Loc::loadMessages(__FILE__);

class HighloadElement extends Base
{
	/** @var int ИД элемента highloadblock */
	protected int $elementId;

	/** @var int ИД highloadblock */
	protected int $hlId;

	public function __construct(int $elementId, int $hlId)
	{
		$this->elementId = $elementId;
		$this->hlId = $hlId;

		$this->entity = 'HIGHLOADBLOCK_' . $this->hlId . '_ELEMENT_' . $this->elementId;
	}

	public function getElementId()
	{
		return $this->elementId;
	}

	public function getHLId()
	{
		return $this->hlId;
	}

	protected function checkExistEntity(): Result
	{
		Loader::includeModule('highloadblock');
		$result = new Result();

		$isExist = false;
		$hlblock = HL\HighloadBlockTable::getById($this->hlId)->fetch();
		if ($hlblock) {
			$entity = HL\HighloadBlockTable::compileEntity($hlblock);
			$entityClass = $entity->getDataClass();
			$isExist = (bool) $entityClass::getList([
				'select' => ['ID'],
				'filter' => [
					'=ID' => $this->elementId
				],
				'limit' => 1,
				'count_total' => true,
			])->getSelectedRowsCount();
		}
		if (!$isExist) {
			$result->addError(
				new Error(
					Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_DONT_EXIST_ENTITY', [
						'#ID#' => $this->elementId,
						'#HL_ID#' => $this->hlId,
					])
				)
			);
		}

		return $result;
	}
}
