<?php

namespace GreenAtom\Attributes\Entity;
use GreenAtom\Attributes\Orm\AttributeTable;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\ORM\Data\{Result, AddResult, UpdateResult, DeleteResult};
use Bitrix\Main\Error;
use Bitrix\Main\Application;

abstract class Base
{
	protected $entity = '';

	/**
	 * Получить список значений атрибутов сущности
	 *
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function get(): Result
	{
		$resultGet = new Result();

		// проверка сущности
		$result = $this->checkExistEntity();
		if (!$result->isSuccess())
			return $result;

		$attributes = [];
		$rsAttributes = AttributeTable::getList([
			'select' => ['TITLE', 'VALUE'],
			'filter' => ['=ENTITY' => $this->entity],
		]);
		while ($attribute = $rsAttributes->fetch()) {
			$attributes[$attribute['TITLE']] = $attribute['VALUE'];
		}

		return $resultGet->setData($attributes);
	}

	/**
	 * Добавить атрибуты и значения сущности
	 *
	 * @param array $attributes
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function add(array $attributes): Result
	{
		$resultAdd = new AddResult();

		// проверка сущности
		$result = $this->checkExistEntity();
		if (!$result->isSuccess())
			return $result;

		// проверяем что нет таких атрибутов
		$attributeTitles = array_keys($attributes);
		$hasTitles = (bool) AttributeTable::getList([
			'select' => ['TITLE', 'VALUE'],
			'filter' => [
				'=ENTITY' => $this->entity,
				'=TITLE' => $attributeTitles,
			],
			'count_total' => true,
		])->getCount();
		if ($hasTitles) {
			return (new AddResult())->addError(
				new Error(Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_ADD'))
			);
		}

		// добавляем
		$rows = [];
		foreach ($attributes as $attributeTitle => $attributeValue) {
			$rows[] = [
				'ENTITY' => $this->entity,
				'TITLE' => $attributeTitle,
				'VALUE' => $attributeValue,
			];
		}
		$resultAdd = AttributeTable::addMulti($rows, false);
		$resultAdd->setData($rows);

		$this->triggerEventEntity();

		return $resultAdd;
	}

	/**
	 * Обновить значения старых атрибутов сущности
	 *
	 * @param array $attributes
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\DB\SqlQueryException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function update(array $attributes): Result
	{
		$resultUpdate = new UpdateResult();

		// проверка сущности
		$result = $this->checkExistEntity();
		if (!$result->isSuccess())
			return $result;

		// проверяем что есть такие атрибуты
		$entityAttributes = [];
		$attributeTitles = array_keys($attributes);
		$rsAttribute = AttributeTable::getList([
			'select' => ['ID', 'TITLE', 'VALUE'],
			'filter' => [
				'=ENTITY' => $this->entity,
				'=TITLE' => $attributeTitles,
			]
		]);
		while ($attribute = $rsAttribute->fetch()) {
			$entityAttributes[$attribute['TITLE']] = $attribute;
		}
		if (count($attributeTitles) !== count($entityAttributes)) {
			return (new UpdateResult())->addError(
				new Error(Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_UPDATE'))
			);
		}

		// обновляем
		Application::getConnection()->startTransaction();
		foreach ($attributes as $attributeTitle => $attributeValue) {
			$entityAttribute = $entityAttributes[$attributeTitle];
			$resultUpdate = AttributeTable::update($entityAttribute['ID'], [
				'VALUE' => $attributeValue
			]);
			if (!$resultUpdate->isSuccess()) {
				Application::getConnection()->rollbackTransaction();
				return $resultUpdate;
			}
		}
		Application::getConnection()->commitTransaction();

		$this->triggerEventEntity();

		return $resultUpdate;
	}

	/**
	 * Удалить атрибуты сущности
	 *
	 * @param array $attributes
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\DB\SqlQueryException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function delete(array $attributes): Result
	{
		$resultDelete = new DeleteResult();

		// проверка сущности
		$result = $this->checkExistEntity();
		if (!$result->isSuccess())
			return $result;

		// проверяем что есть такие атрибуты
		$entityAttributes = [];
		$attributeTitles = array_keys($attributes);
		$rsAttribute = AttributeTable::getList([
			'select' => ['ID', 'TITLE', 'VALUE'],
			'filter' => [
				'=ENTITY' => $this->entity,
				'=TITLE' => $attributeTitles,
			]
		]);
		while ($attribute = $rsAttribute->fetch()) {
			$entityAttributes[$attribute['TITLE']] = $attribute;
		}
		if (count($attributeTitles) !== count($entityAttributes)) {
			return (new DeleteResult())->addError(
				new Error(Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_DELETE'))
			);
		}

		// удаляем
		Application::getConnection()->startTransaction();
		foreach ($attributes as $attributeTitle => $attributeValue) {
			$entityAttribute = $entityAttributes[$attributeTitle];
			$resultDelete = AttributeTable::delete($entityAttribute['ID']);
			if (!$resultDelete->isSuccess()) {
				Application::getConnection()->rollbackTransaction();
				return $resultDelete;
			}
		}
		Application::getConnection()->commitTransaction();

		$this->triggerEventEntity();

		return $resultDelete;
	}

	/**
	 * Удалить все атрибуты сущности
	 *
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\DB\SqlQueryException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function deleteAll(): Result
	{
		$resultDelete = new DeleteResult();

		Application::getConnection()->startTransaction();
		$rsAttribute = AttributeTable::getList([
			'select' => ['ID'],
			'filter' => [
				'=ENTITY' => $this->entity
			]
		]);
		while ($attribute = $rsAttribute->fetch()) {
			$resultDelete = AttributeTable::delete($attribute['ID']);
			if (!$resultDelete->isSuccess()) {
				Application::getConnection()->rollbackTransaction();
				return $resultDelete;
			}
		}
		Application::getConnection()->commitTransaction();

		$this->triggerEventEntity();

		return $resultDelete;
	}

	/**
	 * Сохранение всего набора атрибутов
	 *
	 * @param array $attributesNew
	 * @return Result
	 * @throws \Bitrix\Main\ArgumentException
	 * @throws \Bitrix\Main\ObjectPropertyException
	 * @throws \Bitrix\Main\SystemException
	 */
	public function saveAll(array $attributesNew): Result
	{
		$result = new Result();

		$attributesOld = [];
		$rsAttribute = AttributeTable::getList([
			'select' => ['ID', 'TITLE', 'VALUE'],
			'filter' => [
				'=ENTITY' => $this->entity
			]
		]);
		while ($attribute = $rsAttribute->fetch()) {
			$attributesOld[$attribute['TITLE']] = $attribute;
		}

		// Создаем
		foreach (array_diff_key($attributesNew, $attributesOld) as $attributeTitle => $attributeValue) {
			$resultAdd = AttributeTable::add([
				'ENTITY' => $this->entity,
				'TITLE' => $attributeTitle,
				'VALUE' => $attributeValue,
			]);
			if (!$resultAdd->isSuccess()) {
				$result->addErrors($resultAdd->getErrors());
			}
		}

		// Обновляем/Удаляем
		foreach (array_intersect_key($attributesNew, $attributesOld) as $attributeTitle => $attributeValue) {
			$id = $attributesOld[$attributeTitle]['ID'];
			if (!empty($attributeValue)) {
				$resultUpdate = AttributeTable::update($id, ['VALUE' => $attributeValue]);
				if (!$resultUpdate->isSuccess()) {
					$result->addErrors($resultUpdate->getErrors());
				}
			} else {
				$resultDelete = AttributeTable::delete($id);
				if (!$resultDelete->isSuccess()) {
					$result->addErrors($resultDelete->getErrors());
				}
			}
		}

		// Удаляем
		foreach (array_diff_key($attributesOld, $attributesNew) as $attribute) {
			$resultDelete = AttributeTable::delete($attribute['ID']);
			if (!$resultDelete->isSuccess()) {
				$result->addErrors($resultDelete->getErrors());
			}
		}

		$this->triggerEventEntity();

		return $result;
	}

	/**
	 * Триггер события изменение атрибутов сущности
	 */
	public function triggerEventEntity()
	{
		foreach (\GetModuleEvents('greenatom.attributes', 'OnChangeEntityAttributes', true) as $arEvent) {
			\ExecuteModuleEventEx($arEvent, [$this]);
		}
	}
}
