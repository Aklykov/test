<?php

namespace GreenAtom\Attributes\Entity;
use Bitrix\Main\Localization\Loc;
use Bitrix\Main\Loader;
use Bitrix\Main\Error;
use Bitrix\Main\ORM\Data\Result;

Loc::loadMessages(__FILE__);

class User extends Base
{
	/** @var int ИД пользователя */
	protected int $userId;

	public function __construct(int $userId)
	{
		$this->userId = $userId;

		$this->entity = 'USER_' . $userId;
	}

	public function getUserId()
	{
		return $this->userId;
	}

	protected function checkExistEntity(): Result
	{
		$result = new Result();

		$isExist = (bool) \Bitrix\Main\UserTable::getList([
			'select' => ['ID'],
			'filter' => [
				'=ID' => $this->userId,
			],
			'limit' => 1,
			'count_total' => true,
		])->getSelectedRowsCount();
		if (!$isExist) {
			$result->addError(
				new Error(
					Loc::getMessage('GREENATOM_ATTRIBUTES_ENTITY_ERROR_DONT_EXIST_ENTITY', [
						'#ID#' => $this->userId,
					])
				)
			);
		}

		return $result;
	}

	public static function onAfterDeleteEntityHandler($userId = 0)
	{
		$objEntity = new self($userId);
		$objEntity->deleteAll();
	}
}
