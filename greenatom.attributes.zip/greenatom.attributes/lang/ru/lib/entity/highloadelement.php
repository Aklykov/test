<?php
$MESS['GREENATOM_ATTRIBUTES_ENTITY_ERROR_ADD'] = 'Ошибка добавления атрибутов! Переданы существующие атрибуты!';
$MESS['GREENATOM_ATTRIBUTES_ENTITY_ERROR_UPDATE'] = 'Ошибка обновления атрибутов! Переданы несуществующие атрибуты!';
$MESS['GREENATOM_ATTRIBUTES_ENTITY_ERROR_DELETE'] = 'Ошибка удаления атрибутов! Переданы несуществующие атрибуты!';
$MESS['GREENATOM_ATTRIBUTES_ENTITY_ERROR_DONT_EXIST_ENTITY'] = 'Ошибка! Сущность "ЭЛЕМЕНТ_ИД = #ID# ХАЙЛОАД_ИД = #HL_ID#" не найдена!';